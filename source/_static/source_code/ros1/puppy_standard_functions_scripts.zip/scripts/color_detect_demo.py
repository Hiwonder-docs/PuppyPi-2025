#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2022/4/28 #3
# Author:hiwonder #4
# 第6章 ROS机器狗标准课程\4.ROS+OpenCV视觉识别课程\第6课 颜色识别(6.ROS Robot Standard Course\4.ROS+OpenCV Visual Recognition Course\Lesson 6 Color Recognition) #5
import sys #6
import cv2 #7
import math #8
import rospy #9
import threading #10
import numpy as np #11
from threading import RLock, Timer #12
from std_srvs.srv import * #13
from sensor_msgs.msg import Image #14
from common import Misc #15


ROS_NODE_NAME = 'color_detect_demo' #18

color_range_list = {} #20
detect_color = 'None' #21
color_list = [] #22

range_rgb = { #24
    'red': (0, 0, 255), #25
    'blue': (255, 0, 0), #26
    'green': (0, 255, 0), #27
    'black': (0, 0, 0), #28
    'white': (255, 255, 255), #29
} #30
draw_color = range_rgb["black"] #31

# 找出面积最大的轮廓(find out the contour with the maximal area) #33
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #34
def getAreaMaxContour(contours): #35
    contour_area_temp = 0 #36
    contour_area_max = 0 #37
    area_max_contour = None #38

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #40
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #41
        if contour_area_temp > contour_area_max: #42
            contour_area_max = contour_area_temp #43
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than 50, the contour with the maximal area is considered valid to filter the interference) #44
                area_max_contour = c #45

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #47
def run(img): #48
    global draw_color #49
    global color_list #50
    global detect_color #51
    global action_finish #52
    size = (320, 240) #53

    img_copy = img.copy() #55
    img_h, img_w = img.shape[:2] #56

    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #58
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)       #59
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #60

    max_area = 0 #62
    color_area_max = None     #63
    areaMaxContour_max = 0 #64
    
    for i in color_range_list: #66
        if i in ['red', 'green', 'blue']: #67
            frame_mask = cv2.inRange(frame_lab, #68
                                            (color_range_list[i]['min'][0], #69
                                            color_range_list[i]['min'][1], #70
                                            color_range_list[i]['min'][2]), #71
                                            (color_range_list[i]['max'][0], #72
                                            color_range_list[i]['max'][1], #73
                                            color_range_list[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #74
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #75
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #76
            # if debug: #77
            #     cv2.imshow(i, dilated) #78
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out contour) #79
            areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #80
            if areaMaxContour is not None: #81
                if area_max > max_area:#找最大面积(find the maximal area) #82
                    max_area = area_max #83
                    color_area_max = i #84
                    areaMaxContour_max = areaMaxContour #85
    if max_area > 200:  # 有找到最大面积(the maximal area is found) #86
        ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(get the minimum circumcircle) #87
        centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #88
        centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #89
        radius = int(Misc.map(radius, 0, size[0], 0, img_w))             #90
        cv2.circle(img, (centerX, centerY), radius, range_rgb[color_area_max], 2)#画圆(draw circle) #91
        print("target_color_x: " + str(centerX) + " target_color_y: " + str(centerY) + " target_color_radius: " + str(radius)) #92

        if color_area_max == 'red':  #红色最大(red is the maximal area) #94
            color = 1 #95
        elif color_area_max == 'green':  #绿色最大(green is the maximal area) #96
            color = 2 #97
        elif color_area_max == 'blue':  #蓝色最大(blue is the maximal area) #98
            color = 3 #99
        else: #100
            color = 0 #101
        color_list.append(color) #102

        if len(color_list) == 3:  #多次判断(multiple judgement) #104
            # 取平均值(take average value) #105
            color = int(round(np.mean(np.array(color_list)))) #106
            color_list = [] #107
            if color == 1: #108
                detect_color = 'red' #109
                draw_color = range_rgb["red"] #110
            elif color == 2: #111
                detect_color = 'green' #112
                draw_color = range_rgb["green"] #113
            elif color == 3: #114
                detect_color = 'blue' #115
                draw_color = range_rgb["blue"] #116
            else: #117
                detect_color = 'None' #118
                draw_color = range_rgb["black"]      #119
            print('detect_color is',detect_color)           #120
    else: #121
        detect_color = 'None' #122
        draw_color = range_rgb["black"] #123
            
    cv2.putText(img, "Color: " + detect_color, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, draw_color, 2) #125
    
    return img #127

def image_callback(ros_image): #129

    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #131
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customized image information to image) #132
    cv2_img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #133
    
    frame = cv2_img.copy() #135
    frame_result = frame #136

    frame_result = run(frame) #138
    cv2.imshow('Frame', frame_result) #139
    key = cv2.waitKey(1) #140
    # rgb_image = cv2.cvtColor(frame_result, cv2.COLOR_BGR2RGB).tobytes() #141
    # ros_image.data = rgb_image #142
    # image_pub.publish(ros_image) #143



if __name__ == '__main__': #147
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #148

    color_range_list = rospy.get_param('/lab_config_manager/color_range_list', {}) #150
    rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #151
    image_pub = rospy.Publisher('/%s/image_result'%ROS_NODE_NAME, Image, queue_size=1)  # register result image publisher #152

    try: #154
        rospy.spin() #155
    except KeyboardInterrupt: #156
        print("Shutting down") #157
    finally: #158
        cv2.destroyAllWindows() #159
