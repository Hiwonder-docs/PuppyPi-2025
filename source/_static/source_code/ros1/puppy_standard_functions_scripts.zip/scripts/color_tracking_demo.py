#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2021/12/02 #3
# Author:Hiwonder #4
import sys #5
import cv2 #6
import math #7
import rospy #8
import numpy as np #9
from threading import RLock, Timer #10

from std_srvs.srv import * #12
from sensor_msgs.msg import Image #13
from ros_robot_controller.msg import RGBState, RGBsState #14
from object_tracking.srv import * #15
from puppy_control.msg import Velocity, Pose #16

from common import PID #18
from common import Misc #19

from puppy_control.srv import SetRunActionName #21

ROS_NODE_NAME = 'color_tracking_demo' #23


PuppyPose = {} #26
PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #27


size = (320, 240) #30
start_move = True #31
__target_color = '' #32
__isRunning = False #33
org_image_sub_ed = False #34

x_dis = 500 #36
y_dis = 0.167 #37
Z_DIS = 0.2 #38
z_dis = Z_DIS #39
x_pid = PID.PID(P=0.06, I=0.005, D=0)  # pid初始化(pid initialization) #40
y_pid = PID.PID(P=0.00001, I=0, D=0) #41
z_pid = PID.PID(P=0.003, I=0, D=0) #42

range_rgb = { #44
    'red': (0, 0, 255), #45
    'blue': (255, 0, 0), #46
    'green': (0, 255, 0), #47
    'black': (0, 0, 0), #48
    'white': (255, 255, 255), #49
} #50

lock = RLock() #52

# 找出面积最大的轮廓(find out the contour with the maximal area) #54
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #55
def getAreaMaxContour(contours): #56
    contour_area_temp = 0 #57
    contour_area_max = 0 #58
    area_max_contour = None #59

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #61
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #62
        if contour_area_temp > contour_area_max: #63
            contour_area_max = contour_area_temp #64
            if contour_area_temp > 10:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than 300, the contour with the maximal area is valid to filter the interference) #65
                area_max_contour = c #66

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #68

# 初始位置(initial position) #70
def initMove(delay=False): #71
    runActionGroup_srv('sit.d6ac',False) #72
    with lock: #73
        pass #74
        
    if delay: #76
        rospy.sleep(2) #77

def turn_off_rgb(): #79
    led1 = RGBState() #80
    led1.id = 1 #81
    led1.r = 0 #82
    led1.g = 0 #83
    led1.b = 0 #84

    led2 = RGBState() #86
    led2.id = 2 #87
    led2.r = 0 #88
    led2.g = 0 #89
    led2.b = 0 #90
    msg = RGBsState() #91
    msg.data = [led1,led2] #92
    rgb_pub.publish(msg) #93
    rospy.sleep(0.005) #94

def turn_on_rgb(color): #96
    led1 = RGBState() #97
    led1.id = 1 #98
    led1.r = range_rgb[color][2] #99
    led1.g = range_rgb[color][1] #100
    led1.b = range_rgb[color][0] #101

    led2 = RGBState() #103
    led2.id = 2 #104
    led2.r = range_rgb[color][2] #105
    led2.g = range_rgb[color][1] #106
    led2.b = range_rgb[color][0] #107
    msg = RGBsState() #108
    msg.data = [led1,led2] #109
    rgb_pub.publish(msg) #110
    rospy.sleep(0.005) #111

# 变量重置(variable reset) #113
def reset(): #114
    global x_dis, y_dis, z_dis #115
    global __target_color #116
    
    with lock: #118
        x_dis = 500 #119
        y_dis = 0.167 #120
        z_dis = Z_DIS #121
        x_pid.clear() #122
        y_pid.clear() #123
        z_pid.clear() #124
        turn_off_rgb() #125
        __target_color = '' #126

color_range = None #128
# app初始化调用(app initialization calling) #129
def init(): #130
    global color_range  #131
    
    rospy.loginfo("object tracking Init") #133
    color_range = rospy.get_param('/lab_config_manager/color_range_list', {})  # get lab range from ros param server #134
    initMove() #135
    reset() #136


def run(img): #139
    global PuppyMove #140
    global start_move, timeLast #141
    global x_dis, y_dis, z_dis #142

    img_copy = img.copy() #144
    img_h, img_w = img.shape[:2] #145

    cv2.line(img, (int(img_w / 2 - 10), int(img_h / 2)), (int(img_w / 2 + 10), int(img_h / 2)), (0, 255, 255), 2) #147
    cv2.line(img, (int(img_w / 2), int(img_h / 2 - 10)), (int(img_w / 2), int(img_h / 2 + 10)), (0, 255, 255), 2) #148

    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #150
    frame_lab = cv2.cvtColor(frame_resize, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #151

    area_max = 0 #153
    area_max_contour = 0 #154
    
    if __target_color in color_range: #156
        target_color_range = color_range[__target_color] #157
        frame_mask = cv2.inRange(frame_lab, tuple(target_color_range['min']), tuple(target_color_range['max']))  # 对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #158
        eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  # 腐蚀(corrosion) #159
        dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  # 膨胀(dilation) #160
        contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # 找出轮廓(find out the contour) #161
        area_max_contour, area_max = getAreaMaxContour(contours)  # 找出最大轮廓(find out the contour with the maximal area) #162

    if area_max > 100:  # 有找到最大面积(the maximal area is found) #164
        (center_x, center_y), radius = cv2.minEnclosingCircle(area_max_contour)  # 获取最小外接圆(get the minimum circumcircle) #165
        center_x = int(Misc.map(center_x, 0, size[0], 0, img_w)) #166
        center_y = int(Misc.map(center_y, 0, size[1], 0, img_h)) #167
        radius = int(Misc.map(radius, 0, size[0], 0, img_w)) #168
        if radius > 100: #169
            return img #170
        print('center_x = %d ,center_y=%d'%(int(center_x), int(center_y))) #171
        cv2.circle(img, (int(center_x), int(center_y)), int(radius), range_rgb[__target_color], 2) #172
        if start_move: #173

            x_pid.Kp = 0.003 #175
            x_pid.Ki = 0.00 #176
            x_pid.Kd = 0.00 #177
            x_pid.SetPoint = img_w / 2.0  # 设定(set) #178
            if abs(x_pid.SetPoint - center_x) > 230: #179
                x_pid.Kp = 0.004 #180

            x_pid.update(center_x) #182

            x_dis = x_pid.output #184

            x_dis = np.radians(30) if x_dis > np.radians(30) else x_dis #186
            x_dis = np.radians(-30) if x_dis < np.radians(-30) else x_dis #187
            PuppyPose['roll'] = x_dis #188
            


            if abs(area_max - 900) < 150: #192
                y_dis = 0 #193
            elif area_max - 900 < -150: #194
                y_dis = 10 #195
            elif area_max - 900 > 150: #196
                y_dis = -7 #197
            PuppyMove['x'] = y_dis #198

            z_pid.Kp = 0.0015 #200
            z_pid.Ki = 0.0000 #201
            z_pid.Kd = 0.0000 #202
            z_pid.SetPoint = img_h / 2.0 #203
            

            if abs(z_pid.SetPoint - center_y) > 180: #206
                z_pid.Kp = 0.002 #207
            z_pid.update(center_y) #208
            z_dis = z_pid.output #209

            z_dis = np.radians(30) if z_dis > np.radians(30) else z_dis #211
            z_dis = np.radians(-20) if z_dis < np.radians(-20) else z_dis #212

            PuppyPose['pitch'] = z_dis #214
            print("z_dis:",z_dis) #215
            PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #216
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw']) #217


    return img #220

def image_callback(ros_image): #222
    global lock #223
    
    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #225
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customized image information to image) #226
    cv2_img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #227
    
    frame = cv2_img.copy() #229
    frame_result = frame #230
    with lock: #231
        if __isRunning: #232
            frame_result = run(frame) #233
            cv2.imshow('Frame', frame_result) #234
            key = cv2.waitKey(1) #235

def enter_func(msg): #237
    global lock #238
    global image_sub #239
    global __isRunning #240
    global org_image_sub_ed #241
    
    rospy.loginfo("enter object tracking") #243
    init() #244
    with lock: #245
        if not org_image_sub_ed: #246
            org_image_sub_ed = True #247
            image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #248
            
    puppy_set_running_srv(True) #250
    return [True, 'enter'] #251

heartbeat_timer = None #253
def exit_func(msg): #254
    global lock #255
    global image_sub #256
    global __isRunning #257
    global org_image_sub_ed #258
    
    rospy.loginfo("exit object tracking") #260
    with lock: #261
        __isRunning = False #262
        reset() #263
        try: #264
            if org_image_sub_ed: #265
                org_image_sub_ed = False #266
                if heartbeat_timer:heartbeat_timer.cancel() #267
                image_sub.unregister() #268
        except BaseException as e: #269
            rospy.loginfo('%s', e) #270
    

    return [True, 'exit'] #273

def start_running(): #275
    global lock #276
    global __isRunning #277
    
    rospy.loginfo("start running object tracking") #279
    with lock: #280
        __isRunning = True #281

def stop_running(): #283
    global lock #284
    global __isRunning #285
    
    rospy.loginfo("stop running object tracking") #287
    with lock: #288
        __isRunning = False #289
        reset() #290
        # initMove(delay=False) #291

def set_running(msg): #293
    if msg.data: #294
        start_running() #295
    else: #296
        stop_running() #297
        
    return [True, 'set_running'] #299

def set_target(msg): #301
    global lock #302
    global __target_color #303
    
    rospy.loginfo("%s", msg) #305
    with lock: #306
        __target_color = msg.data #307
        turn_on_rgb(__target_color) #308
        
    return [True, 'set_target'] #310

def heartbeat_srv_cb(msg): #312
    global heartbeat_timer #313

    if isinstance(heartbeat_timer, Timer): #315
        heartbeat_timer.cancel() #316
    if msg.data: #317
        heartbeat_timer = Timer(5, rospy.ServiceProxy('/object_tracking/exit', Trigger)) #318
        heartbeat_timer.start() #319
    rsp = SetBoolResponse() #320
    rsp.success = msg.data #321

    return rsp #323


def cleanup(): #326
    turn_off_rgb() #327
    print('is_shutdown') #328

if __name__ == '__main__': #330
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #331
    rospy.on_shutdown(cleanup) #332

    PP = rospy.get_param('/puppy_control/PuppyPose') #334
    PuppyPose = PP['Stand'].copy() #335

    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #337
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #338


    image_pub = rospy.Publisher('/%s/image_result'%ROS_NODE_NAME, Image, queue_size=1)  # register result image publisher #341
    rgb_pub = rospy.Publisher('/ros_robot_controller/set_rgb', RGBsState, queue_size=1) #342
    
    runActionGroup_srv = rospy.ServiceProxy('/puppy_control/runActionGroup', SetRunActionName) #344
    puppy_set_running_srv = rospy.ServiceProxy('/puppy_control/set_running', SetBool) #345

    debug = True #347
    if debug: #348
        rospy.sleep(0.2) #349
        enter_func(1) #350
        
        msg = SetTarget() #352
        msg.data = 'red' #353
        
        set_target(msg) #355
        start_running() #356

    try: #358
        rospy.spin() #359
    except KeyboardInterrupt: #360
        rospy.loginfo("Shutting down") #361
    finally: #362
        cv2.destroyAllWindows() #363
