#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2022/4/28 #3
# Author:hiwonder #4
import sys #5
import cv2 #6
import math #7
import rospy #8
import threading #9
import numpy as np #10
from threading import RLock, Timer #11
from std_srvs.srv import * #12
from sensor_msgs.msg import Image #13
from common import apriltag #14

ROS_NODE_NAME = 'apriltag_detect_demo' #16

coordinate = None #18

tag_id = None #20
haved_detect = False #21



detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #25
camera_intrinsic = np.matrix([  [619.063979, 0,          302.560920], #26
                                [0,          613.745352, 237.714934], #27
                                [0,          0,          1]]) #28
# 相机内参(camera internal reference) #29


times = 0 #32
def apriltagDetect(img):   #33
    global times #34
    global coordinate #35

    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) #37
    detections = detector.detect(gray, return_image=False) #38
    if len(detections) != 0: #39
        for detection in detections: #40
            M,e0,e1 = detector.detection_pose(detection,[camera_intrinsic.item(0,0), camera_intrinsic.item(1,1), #41
                                                                camera_intrinsic.item(0,2), camera_intrinsic.item(1,2)], #42
                                                                0.033) #43
                    
            P = M[:3,:4] #45
            coordinate=np.matmul(P,np.array([[0],[0],[0],[1]])).flatten() #46
            print('coordinate =',coordinate)     #47

            corners = np.rint(detection.corners)  # 获取四个角点(get for corners) #49
            cv2.drawContours(img, [np.array(corners, int)], -1, (0, 255, 255), 5, cv2.LINE_AA) #50
            tag_family = str(detection.tag_family, encoding='utf-8')  # 获取tag_family(get tag_family) #51
            times = 0 #52
            if tag_family == 'tag36h11': #53
                tag_id = str(detection.tag_id)  # 获取tag_id(get tag_id) #54
                print('tag_id =',tag_id) #55
                return tag_id #56
            else: #57
                return None #58
            
    else: #60
        times += 1 #61
        if times >= 3: #62
            coordinate = None #63
        return None #64

def run(img): #66
    global tag_id #67
    global haved_detect #68

    tag_id = apriltagDetect(img) # apriltag检测(apriltag detection) #70
    if tag_id is not None and not haved_detect: #71
        haved_detect = True #72
    cv2.putText(img, tag_id, (10, img.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 3) #73
    return img #74


def image_callback(ros_image): #77

    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #79
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customized image information to image) #80
    cv2_img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #81
    
    frame = cv2_img.copy() #83
    frame_result = frame #84

    frame_result = run(frame) #86
    cv2.imshow('image', frame_result) #87
    cv2.waitKey(1) #88
    

if __name__ == '__main__': #91
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #92


    rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #95
    image_pub = rospy.Publisher('/%s/image_result'%ROS_NODE_NAME, Image, queue_size=1)  # register result image publisher #96

    rospy.sleep(0.2) #98


    try: #101
        rospy.spin() #102
    except KeyboardInterrupt: #103
        print("Shutting down") #104
    finally: #105
        cv2.destroyAllWindows() #106
