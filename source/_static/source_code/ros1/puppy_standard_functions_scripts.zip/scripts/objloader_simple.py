class OBJ: #1
    def __init__(self, filename, swapyz=False): #2
        """Loads a Wavefront OBJ file. """ #3
        self.vertices = [] #4
        self.normals = [] #5
        self.texcoords = [] #6
        self.faces = [] #7

        material = None #9
        for line in open(filename, "r"): #10
            if line.startswith('#'): continue #11
            values = line.split() #12
            if not values: continue #13
            if values[0] == 'v': #14
                v = list(map(float, values[1:])) #15
                if swapyz and len(v) > 3: #16
                    v = v[0], v[2], v[1], v[3], v[4], v[5] #17
                elif swapyz: #18
                    v = v[0], v[2], v[1] #19
                self.vertices.append(v) #20
            elif values[0] == 'vn': #21
                v = list(map(float, values[1:4])) #22
                if swapyz: #23
                    v = v[0], v[2], v[1] #24
                self.normals.append(v) #25
            elif values[0] == 'vt': #26
                self.texcoords.append(map(float, values[1:3])) #27
            elif values[0] in ('usemtl', 'usemat'): #28
                material = values[1] #29
            elif values[0] == 'f': #30
                face = [] #31
                texcoords = [] #32
                norms = [] #33
                for v in values[1:]: #34
                    w = v.split('/') #35
                    face.append(int(w[0])) #36
                    if len(w) >= 2 and len(w[1]) > 0: #37
                        texcoords.append(int(w[1])) #38
                    else: #39
                        texcoords.append(0) #40
                    if len(w) >= 3 and len(w[2]) > 0: #41
                        norms.append(int(w[2])) #42
                    else: #43
                        norms.append(0) #44
                self.faces.append((face, norms, texcoords)) #45
