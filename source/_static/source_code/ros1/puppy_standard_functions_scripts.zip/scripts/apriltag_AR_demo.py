#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2021/12/02 #3
# Author:Hiwonder #4
# 4.ROS+OpenCV视觉识别课程\第8课 AR视觉(4.ROS+OpenCV Visual Recognition Course\Lesson 8 AR Vision) #5

import os #7
import cv2 #8
import math #9
import rospy #10
import numpy as np #11
import threading #12
from common import apriltag #13
from objloader_simple import OBJ as obj_load #14
from sensor_msgs.msg import CameraInfo, Image #15
from std_srvs.srv import Trigger, TriggerRequest, TriggerResponse #16
from scipy.spatial.transform import Rotation as R #17

ROS_NODE_NAME = 'apriltag_AR_demo' #19

MODEL_PATH = '/home/ubuntu/puppypi/src/puppy_standard_functions/models' #21

OBJP = np.array([[-1, -1,  0], #23
                 [ 1, -1,  0], #24
                 [-1,  1,  0], #25
                 [ 1,  1,  0], #26
                 [ 0,  0,  0]], dtype=np.float32) #27

AXIS = np.float32([[-1, -1, 0],  #29
                   [-1,  1, 0],  #30
                   [ 1,  1, 0],  #31
                   [ 1, -1, 0], #32
                   [-1, -1, 2], #33
                   [-1,  1, 2], #34
                   [ 1,  1, 2], #35
                   [ 1, -1, 2]]) #36


MODELS_SCALE = { #39
                'bicycle': 50,  #40
                'fox': 4,  #41
                'chair': 400,  #42
                'cow': 0.4, #43
                'wolf': 0.6, #44
                } #45
                # 'pirate-ship-fat': 100} #46


def draw(img, corners, imgpts): #49
    imgpts = np.int32(imgpts).reshape(-1,2) #50
    cv2.drawContours(img, [imgpts[:4]],-1,(0, 255, 0),-3) #51
    for i,j in zip(range(4),range(4,8)): #52
        cv2.line(img, tuple(imgpts[i]), tuple(imgpts[j]),(255),3) #53
    cv2.drawContours(img, [imgpts[4:]],-1,(0, 0, 255),3) #54
    return img #55


class ARNode: #58
    def __init__(self, name): #59
        rospy.init_node(name) #60
        self.model_path = rospy.get_param("~/model_path", MODEL_PATH) #61
        self.name = name #62
        self.camera_intrinsic = np.matrix([[619.063979, 0,          302.560920], #63
                                           [0,          613.745352, 237.714934], #64
                                           [0,          0,          1]]) #65
        self.dist_coeffs = np.array([0.103085, -0.175586, -0.001190, -0.007046, 0.000000]) #66
        self.obj = None #67
        self.target_model = None #68
        self.tag_detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #69

        
        self.lock = threading.RLock() #72
        self.image_sub = None #73
        self.camera_info_sub = None #74
        self.result_publisher = rospy.Publisher(self.name + '/image_result', Image, queue_size=1) #75
        

    def enter_srv_callback(self, _): #78
        rospy.loginfo("enter") #79
        try: #80
            if self.image_sub:self.image_sub.unregister() #81
        except Exception as e: #82
            rospy.logerr(str(e)) #83

        with self.lock: #85
            self.obj = None #86
            self.target_model = None #87
            self.image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, self.image_callback, queue_size=1) #88
            
        return TriggerResponse(success=True) #90

    def exit_srv_callback(self, _): #92
        rospy.loginfo("exit") #93
        try: #94
            if self.image_sub:self.image_sub.unregister() #95
        except Exception as e: #96
            rospy.logerr(str(e)) #97
        return TriggerResponse(success=True) #98
        

    def set_model_srv_callback(self, model): #101
        with self.lock: #102
            if model == "": #103
                self.target_model = None #104
            else: #105
                self.target_model = model #106
                if self.target_model != 'rectangle': #107
                    obj = obj_load(os.path.join(self.model_path, self.target_model + '.obj'), swapyz=True) #108
                    obj.faces = obj.faces[::-1] #109
                    new_faces = [] #110
                    for face in obj.faces: #111
                        face_vertices = face[0] #112
                        points = [] #113
                        colors = [] #114
                        for vertex in face_vertices: #115
                            data = obj.vertices[vertex - 1] #116
                            points.append(data[:3]) #117
                            if self.target_model != 'cow' and self.target_model != 'wolf': #118
                                colors.append(data[3:]) #119
                        scale_matrix = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]]) * MODELS_SCALE[self.target_model] #120
                        points = np.dot(np.array(points), scale_matrix) #121
                        if self.target_model == 'bicycle': #122
                            points = np.array([[p[0] - 670, p[1] - 350, p[2]] for p in points]) #123
                            points = R.from_euler('xyz', (0, 0, 180), degrees=True).apply(points) #124
                        elif self.target_model == 'fox': #125
                            points = np.array([[p[0], p[1], p[2]] for p in points]) #126
                            points = R.from_euler('xyz', (0, 0, -90), degrees=True).apply(points) #127
                        elif self.target_model == 'chair': #128
                            points = np.array([[p[0], p[1], p[2]] for p in points]) #129
                            points = R.from_euler('xyz', (0, 0, -90), degrees=True).apply(points) #130
                        else: #131
                            points = np.array([[p[0], p[1], p[2]] for p in points]) #132
                        if len(colors) > 0: #133
                            color = tuple(255 * np.array(colors[0])) #134
                        else: #135
                            color = None #136
                        new_faces.append((points, color)) #137

                    self.obj = new_faces #139

    def camera_info_callback(self, msg): #141
        with self.lock: #142
            pass #143

    def image_callback(self, ros_image: Image): #145
        #rospy.loginfo("image recv") #146
        rgb_image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8,  #147
                        buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customized image information to image) #148
        result_image = np.copy(rgb_image) #149
        
        with self.lock: #151
            try: #152
                result_image = self.image_proc(rgb_image, result_image) #153
            except Exception as e: #154
                rospy.logerr(str(e)) #155
        

        cv2.imshow('image', cv2.cvtColor(result_image, cv2.COLOR_RGB2BGR)) #158
        cv2.waitKey(1) #159
        
    def image_proc(self, rgb_image, result_image): #161
        if self.target_model is not None:  #162
            gray = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2GRAY) #163
            detections = self.tag_detector.detect(gray) #164
            if detections != (): #165
                
                for detection in detections: #167
                    M,e0,e1 = self.tag_detector.detection_pose(detection,[self.camera_intrinsic.item(0,0), self.camera_intrinsic.item(1,1), #168
                                                                self.camera_intrinsic.item(0,2), self.camera_intrinsic.item(1,2)], #169
                                                                0.033) #170
                    
                    P = M[:3,:4] #172
                    coordinate=np.matmul(P,np.array([[0],[0],[0],[1]])) #173
                    print('coordinate = ',coordinate) #174

                    tag_id = detection.tag_id #176
                    tag_center = detection.center #177
                    tag_corners = detection.corners #178

                    print('tag_id = ',tag_id) #180

                    lb = tag_corners[0] #182
                    rb = tag_corners[1] #183
                    rt = tag_corners[2] #184
                    lt = tag_corners[3] #185
                    cv2.circle(result_image, (int(lb[0]), int(lb[1])), 2, (0, 255, 255), -1) #186
                    cv2.circle(result_image, (int(lt[0]), int(lt[1])), 2, (0, 255, 255), -1) #187
                    cv2.circle(result_image, (int(rb[0]), int(rb[1])), 2, (0, 255, 255), -1) #188
                    cv2.circle(result_image, (int(rt[0]), int(rt[1])), 2, (0, 255, 255), -1) #189
                    
                    corners = np.array([lb, rb, lt, rt, tag_center]).reshape(5, -1) #191
                    ret, rvecs, tvecs = cv2.solvePnP(OBJP, corners, self.camera_intrinsic, self.dist_coeffs) #192
                    if self.target_model == 'rectangle': #193
                        imgpts, jac = cv2.projectPoints(AXIS, rvecs, tvecs, self.camera_intrinsic, self.dist_coeffs) #194
                        result_image = draw(result_image, corners, imgpts) #195
                    else: #196
                         for points, color in self.obj: #197
                             dst, jac = cv2.projectPoints(points.reshape(-1, 1, 3)/100.0, rvecs, tvecs, self.camera_intrinsic, self.dist_coeffs) #198
                             imgpts = dst.astype(int) #199
                             # 手动上色(manually apply color) #200
                             if self.target_model == 'cow': #201
                                 cv2.fillConvexPoly(result_image, imgpts, (0, 255, 255)) #202
                             elif self.target_model == 'wolf': #203
                                 cv2.fillConvexPoly(result_image, imgpts, (255, 255, 0)) #204
                             else: #205
                                 cv2.fillConvexPoly(result_image, imgpts, color) #206
        return result_image #207

def main(): #209
    ar_app_node = ARNode('apriltag_AR_demo') #210
    ar_app_node.enter_srv_callback(1) #211
    ar_app_node.set_model_srv_callback('bicycle') #212
    try: #213
        rospy.spin() #214
    except Exception as e: #215
        rospy.logerr(str(e)) #216
        rospy.loginfo("Shutting down") #217


if __name__ == '__main__': #220
    main() #221
