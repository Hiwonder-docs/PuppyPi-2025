#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2021/12/02 #3
# Author:hiwonder #4
import sys #5
import cv2 #6
import math #7
import rospy #8
import threading #9
import numpy as np #10
from threading import RLock, Timer #11
from std_srvs.srv import * #12
from sensor_msgs.msg import Image #13
from common import apriltag #14
from puppy_control.srv import SetRunActionName #15
from puppy_control.msg import Velocity, Pose, Gait #16

ROS_NODE_NAME = 'apriltag_tracking_demo' #18

coordinate = None # 标签距离摄像头的坐标[x，y，z]，单位米(coordinates of the tag relative to the camera [x, y, z], measured in meters) #20
GaitConfig = {'overlap_time':0.2, 'swing_time':0.15, 'clearance_time':0.0, 'z_clearance':4} #21

# # 用到的动作组名称(the used name of action group) #23
# id_1_action = 'shake_hands.d6ac' #24
# id_2_action = 'lie_down.d6ac' #25
# id_3_action = 'push-up.d6ac' #26

tag_id = None #28
haved_detect = False #29

__isRunning = False #31

org_image_sub_ed = False #33


action_finish = True #36

lock = RLock() #38

detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #40
camera_intrinsic = np.matrix([  [619.063979, 0,          302.560920], #41
                                [0,          613.745352, 237.714934], #42
                                [0,          0,          1]]) #43
# 变量重置(variable reset) #44
def reset(): #45
    global tag_id #46
    global haved_detect #47
    with lock: #48
        tag_id = None #49
        haved_detect = False #50


# 初始位置(initial position) #53
def initMove(delay=False): #54
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #55
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #56
    
    rospy.sleep(0.2) #58
    PuppyGaitConfigPub.publish(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #59
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #60
    
    with lock: #62
        pass #63
    if delay: #64
        rospy.sleep(1) #65

# app初始化调用(app initialization calling) #67
def init(): #68
    print("color detect Init") #69
    initMove(True) #70
    reset() #71

def move(): #73
    global haved_detect #74
    global coordinate #75
    rospy.sleep(1) #76
    while True: #77
        if __isRunning: #78
            if coordinate is None: #79
                PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #80
                rospy.sleep(0.01)    #81
            else: #82
                if coordinate[2] > 0.22: #83
                    PuppyVelocityPub.publish(x=5, y=0, yaw_rate=0) #84
                elif coordinate[2] < 0.18: #85
                    PuppyVelocityPub.publish(x=-5, y=0, yaw_rate=0) #86
                else: #87
                    PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #88
            rospy.sleep(0.01)          #89
        else: #90
            rospy.sleep(0.01) #91
            
# 运行子线程(run sub-thread) #93
th = threading.Thread(target=move,daemon=True) #94
# th.start() #95

times = 0 #97
def apriltagDetect(img):   #98
    global times #99
    global coordinate #100

    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) #102
    detections = detector.detect(gray, return_image=False) #103
    if len(detections) != 0: #104
        for detection in detections: #105
            M,e0,e1 = detector.detection_pose(detection,[camera_intrinsic.item(0,0), camera_intrinsic.item(1,1), #106
                                                                camera_intrinsic.item(0,2), camera_intrinsic.item(1,2)], #107
                                                                0.033) #108
                    
            P = M[:3,:4] #110
            coordinate=np.matmul(P,np.array([[0],[0],[0],[1]])).flatten() #111
            print('coordinate = ',coordinate)     #112

            # corners = np.rint(detection.corners)  # 获取四个角点(get four corners) #114
            # cv2.drawContours(img, [np.array(corners, np.int)], -1, (0, 255, 255), 5, cv2.LINE_AA) #115
            tag_family = str(detection.tag_family, encoding='utf-8')  # 获取tag_family(get tag_family) #116
            times = 0 #117
            if tag_family == 'tag36h11': #118
                tag_id = str(detection.tag_id)  # 获取tag_id(get tag_id) #119
                return tag_id #120
            else: #121
                return None #122
            
    else: #124
        times += 1 #125
        if times >= 3: #126
            coordinate = None #127
        return None #128

def run(img): #130
    global tag_id #131
    global haved_detect #132

    if not __isRunning: #134
        return img #135
    
    tag_id = apriltagDetect(img) # apriltag检测(apriltag detection) #137
    if tag_id is not None and not haved_detect: #138
        haved_detect = True #139
    cv2.putText(img, tag_id, (10, img.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 255), 3) #140
    return img #141


def image_callback(ros_image): #144
    global lock #145
    
    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #147
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customized image information to image) #148
    cv2_img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #149
    
    frame = cv2_img.copy() #151
    frame_result = frame #152
    with lock: #153
        if __isRunning: #154
            frame_result = run(frame) #155
    cv2.imshow('image', frame_result) #156
    cv2.waitKey(1) #157
    # rgb_image = cv2.cvtColor(frame_result, cv2.COLOR_BGR2RGB).tobytes() #158
    # ros_image.data = rgb_image #159
    # image_pub.publish(ros_image) #160

def enter_func(msg): #162
    global lock #163
    global image_sub #164
    global __isRunning #165
    global org_image_sub_ed #166

    rospy.loginfo("enter apriltag detect") #168
    with lock: #169
        init() #170
        if not org_image_sub_ed: #171
            org_image_sub_ed = True #172
            image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #173
            
    return [True, 'enter'] #175

heartbeat_timer = None #177
def exit_func(msg): #178
    global lock #179
    global image_sub #180
    global __isRunning #181
    global org_image_sub_ed #182
    
    rospy.loginfo("exit apriltag detect") #184
    with lock: #185
        __isRunning = False #186
        try: #187
            if org_image_sub_ed: #188
                org_image_sub_ed = False #189
                heartbeat_timer.cancel() #190
                image_sub.unregister() #191
        except: #192
            pass #193
    
    return [True, 'exit'] #195

def start_running(): #197
    global lock #198
    global __isRunning #199

    rospy.loginfo("start running apriltag detect") #201
    with lock: #202
        __isRunning = True #203

def stop_running(): #205
    global lock #206
    global __isRunning #207

    rospy.loginfo("stop running apriltag detect") #209
    with lock: #210
        __isRunning = False #211
        reset() #212
        initMove(delay=False) #213

def set_running(msg): #215
    if msg.data: #216
        start_running() #217
    else: #218
        stop_running() #219
    
    return [True, 'set_running'] #221

def heartbeat_srv_cb(msg): #223
    global heartbeat_timer #224
    
    if isinstance(heartbeat_timer, Timer): #226
        heartbeat_timer.cancel() #227
    if msg.data: #228
        heartbeat_timer = Timer(5, rospy.ServiceProxy('/%s/exit'%ROS_NODE_NAME, Trigger)) #229
        heartbeat_timer.start() #230
    rsp = SetBoolResponse() #231
    rsp.success = msg.data #232

    return rsp #234
def cleanup(): #235
    PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #236
    print('is_shutdown') #237
if __name__ == '__main__': #238
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #239
    rospy.on_shutdown(cleanup) #240
    
    PP = rospy.get_param('/puppy_control/PuppyPose') #242
    PuppyPose = PP['Stand'].copy() #243
    # PG = rospy.get_param('/puppy_control/GaitConfig') #244
    # GaitConfig = PG['GaitConfigFast'].copy() #245


    image_pub = rospy.Publisher('/%s/image_result'%ROS_NODE_NAME, Image, queue_size=1)  # register result image publisher #248

    # enter_srv = rospy.Service('/%s/enter'%ROS_NODE_NAME, Trigger, enter_func) #250
    # exit_srv = rospy.Service('/%s/exit'%ROS_NODE_NAME, Trigger, exit_func) #251
    # running_srv = rospy.Service('/%s/set_running'%ROS_NODE_NAME, SetBool, set_running) #252
    # heartbeat_srv = rospy.Service('/%s/heartbeat'%ROS_NODE_NAME, SetBool, heartbeat_srv_cb) #253
    # runActionGroup_srv = rospy.ServiceProxy('/puppy_control/runActionGroup', SetRunActionName) #254

    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #256
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #257
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #258
    rospy.sleep(0.2) #259

    debug = True #261
    if debug: #262
        enter_func(1) #263
        start_running() #264
    
    th.start() #266

    try: #268
        rospy.spin() #269
    except KeyboardInterrupt: #270
        print("Shutting down") #271
    finally: #272
        cv2.destroyAllWindows() #273
