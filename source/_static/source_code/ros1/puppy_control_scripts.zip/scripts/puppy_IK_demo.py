#!/usr/bin/python3 #1
# coding=utf8 #2
# Author:hiwonder #3

import os, sys, time #5
import numpy as np #6


sys.path.append('/home/ubuntu/software/puppypi_control/') #9
from servo_controller import setServoPulse #10
from HiwonderPuppy import HiwonderPuppy, PWMServoParams #11


puppy = HiwonderPuppy(setServoPulse = setServoPulse, servoParams = PWMServoParams(), dof = '8') #14
                            # FR    FL    BR     BL #15
foot_locations = np.array([ [ -1.,  -1.,  -1.,   -1.], # X #16
                            [ 0.,    0.,   0.,    0.], # Y #17
                            [-10,   -10,  -10,   -10,] # Z #18
                            ]) #19
# 相对4条腿各自坐标系的坐标值，单位cm(coordinates relative to the coordinate system of each of the four legs, measured in centimeters) #20


foot_locations = foot_locations/100 # 换算成以米为单位(coordinates converted to meters as the unit of measurement) #23

joint_angles = puppy.fourLegsRelativeCoordControl(foot_locations) #25
# 输入坐标，通过逆运动学计算得到各个舵机的角度值(input coordinates to calculate the angle values of each servo motor through inverse kinematics) #26
print(joint_angles*57.3) #27

puppy.servo_force_run() #29
# 强制执行舵机角度转动，没有这句舵机有时候不会转动(enforce servo angle rotation, without this command, servos may not always rotate) #30

puppy.sendServoAngle(joint_angles, time = 500) #32
#将舵机角度发送到舵机，(send the servo angles to the servo motors) #33


while True: #36
    time.sleep(0.001) #37
