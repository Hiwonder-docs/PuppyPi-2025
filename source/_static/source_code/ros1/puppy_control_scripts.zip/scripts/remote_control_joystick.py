#!/usr/bin/env python3 #1
# coding=utf8 #2
import os #3
import sys #4
import rospy #5
import threading #6
import math #7
import numpy as np #8
import pygame as pg #9
from functools import partial #10
import time  # 导入time模块 #11

from ros_robot_controller.msg import BuzzerState #13
from geometry_msgs.msg import Polygon #14
from puppy_control.msg import Velocity, Pose #15
from std_msgs.msg import Float32 #16
from std_srvs.srv import Empty, SetBool #17


# PuppyPose #20

PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #22
Stand = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #23

ROS_NODE_NAME = 'remote_control_joystick' #25


enable_control = True #28

PRESSED_ACTION_MAP = {} #30
HOLD_ACTION_MAP = {} #31
RELEASED_ACTION_MAP = {} #32
BUTTONS0 = ("CROSS", "CIRCLE", "None_1", "SQUARE", #33
           "TRIANGLE", "None_2", "L1", "R1", #34
           "L2", "R2", "SELECT", "START", "MODE", #35
           "L_HAT_LEFT", "L_HAT_RIGHT", "L_HAT_DOWN", "L_HAT_UP", #36
           "L_AXIS_LEFT", "L_AXIS_RIGHT", "L_AXIS_UP", "L_AXIS_DOWN", #37
           "R_AXIS_LEFT", "R_AXIS_RIGHT", "R_AXIS_UP", "R_AXIS_DOWN") #38
BUTTONS = ("TRIANGLE", "CIRCLE", "CROSS", "SQUARE", #39
           "L1", "R1", "L2", "R2", #40
           "SELECT", "START", "L_AXIS_BUTTON", "R_AXIS_BUTTON", "MODE", #41
           "L_HAT_LEFT", "L_HAT_RIGHT", "L_HAT_DOWN", "L_HAT_UP", #42
           "L_AXIS_LEFT", "L_AXIS_RIGHT", "L_AXIS_UP", "L_AXIS_DOWN", #43
           "R_AXIS_LEFT", "R_AXIS_RIGHT", "R_AXIS_UP", "R_AXIS_DOWN")  #44




LegsCoord = None #49

VelocityX = 15 #51



def go_home(): #55
    global PuppyPose, PuppyMove #56
    print('go_home') #57
    # PuppyPose = PP.Stand.copy() #58
    PuppyPose = Stand.copy() #59
    PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #60
    rospy.ServiceProxy('/puppy_control/go_home', Empty)() #61
    msg = BuzzerState() #62
    msg.freq = 1900 #63
    msg.on_time = 0.1 #64
    msg.off_time = 0.9 #65
    msg.repeat = 1 #66
    buzzer_pub.publish(msg) #67
    rospy.loginfo(PuppyPose) #68


def LegsCoordFun(msg): #71
    global LegsCoord #72
    LegsCoord = msg #73


def PressedFun(*args,**kwargs): #76
    global LegsCoord #77
    global VelocityX #78
    # print('PressedFun',args,kwargs)  #79

    if (js.get_button_state('L_HAT_UP') or js.get_button_state('L_AXIS_UP')  #81
        or js.get_button_state('L_HAT_DOWN') or js.get_button_state('L_AXIS_DOWN') #82
        ): #83
        if kwargs['key'] == 'CIRCLE': #84
            VelocityX += 1 #85
        elif kwargs['key'] == 'SQUARE': #86
            VelocityX -= 1 #87

        if VelocityX > 25:VelocityX = 25 #89
        elif VelocityX < 5:VelocityX = 5 #90

        if PuppyMove['x'] > 0: #92
            PuppyMove['x'] = VelocityX #93
        elif PuppyMove['x'] < 0: #94
            PuppyMove['x'] = -VelocityX #95
        PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #96
        rospy.loginfo(PuppyMove['x']) #97

    if kwargs['key'] in PuppyMove.keys(): #99
        # print(kwargs['key'],args[0]) #100

        if kwargs['key'] == 'x': #102
            if args[0] > 0: #103
                PuppyMove['x'] = VelocityX #104
            else: #105
                PuppyMove['x'] = -VelocityX #106
        else: #107
            PuppyMove[kwargs['key']] = args[0] #108
        PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #109
        rospy.loginfo(PuppyMove['x']) #110
    elif kwargs['key'] in PuppyPose.keys():  #111
        if kwargs['key'] == 'height': #112
            PuppyPose['height'] += args[0] #113
            if PuppyPose['height'] < -16:PuppyPose['height'] = -16 #114
            if PuppyPose['height'] > -5:PuppyPose['height'] = -5 #115
        if kwargs['key'] == 'x_shift': #116
            PuppyPose['x_shift'] += args[0] #117
            if PuppyPose['x_shift'] < -6:PuppyPose['x_shift'] = -6 #118
            if PuppyPose['x_shift'] > 6:PuppyPose['x_shift'] = 6 #119
        if kwargs['key'] == 'pitch': #120
            PuppyPose['pitch'] += args[0] #121
            if PuppyPose['pitch'] < -np.radians(20):PuppyPose['pitch'] = -np.radians(20) #122
            if PuppyPose['pitch'] > np.radians(20):PuppyPose['pitch'] = np.radians(20) #123
        PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #124
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw']) #125
        rospy.loginfo(PuppyPose) #126
    elif kwargs['key'] == 'legs_coord': #127
        print(LegsCoord) #128


def HoldFun(*args,**kwargs): #131
    global VelocityX #132
    # rospy.logdebug('HoldFun',args,kwargs) #133
    if kwargs['key'] in PuppyPose.keys():  #134
        if kwargs['key'] == 'height': #135
            PuppyPose['height'] += args[0] #136
            if PuppyPose['height'] < -16:PuppyPose['height'] = -16 #137
            if PuppyPose['height'] > -5:PuppyPose['height'] = -5 #138
        if kwargs['key'] == 'x_shift': #139
            PuppyPose['x_shift'] += args[0] #140
            if PuppyPose['x_shift'] < -6:PuppyPose['x_shift'] = -6 #141
            if PuppyPose['x_shift'] > 6:PuppyPose['x_shift'] = 6 #142
        if kwargs['key'] == 'pitch': #143
            PuppyPose['pitch'] += args[0] #144
            if PuppyPose['pitch'] < -np.radians(20):PuppyPose['pitch'] = -np.radians(20) #145
            if PuppyPose['pitch'] > np.radians(20):PuppyPose['pitch'] = np.radians(20) #146
        PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #147
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw']) #148
        rospy.loginfo(PuppyPose) #149

    if (js.get_button_state('L_HAT_UP') or js.get_button_state('L_AXIS_UP')  #151
        or js.get_button_state('L_HAT_DOWN') or js.get_button_state('L_AXIS_DOWN') #152
        ): #153
        if kwargs['key'] == 'CIRCLE': #154
            VelocityX += 0.5 #155
        elif kwargs['key'] == 'SQUARE': #156
            VelocityX -= 0.5 #157

        if VelocityX > 25:VelocityX = 25 #159
        elif VelocityX < 5:VelocityX = 5 #160

        if PuppyMove['x'] > 0: #162
            PuppyMove['x'] = VelocityX #163
        elif PuppyMove['x'] < 0: #164
            PuppyMove['x'] = -VelocityX #165

        PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #167
        rospy.loginfo('HoldFun  %f'% PuppyMove['x']) #168

def ReleaseFun(*args,**kwargs): #170
    if kwargs['key'] in PuppyMove.keys(): #171
        PuppyMove[kwargs['key']] = args[0] #172
        PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #173

# Predefine all possible key-action mappings for easy selection based on joystick type later. （预先定义好所有可能的按键动作映射，方便后续根据手柄类型选择） #175
PRESSED_ACTION_MAP_BUTTONS0 = { #176
    "START": go_home, #177
    "SELECT": partial(PressedFun, 0, key = 'legs_coord'), #178

    "L_HAT_UP": partial(PressedFun, 1, key = 'x'), #180
    "L_AXIS_UP": partial(PressedFun, 1, key = 'x'), #181
    "L_HAT_DOWN": partial(PressedFun, -1, key = 'x'), #182
    "L_AXIS_DOWN": partial(PressedFun, -1, key = 'x'), #183
    "L_HAT_LEFT": partial(PressedFun, np.radians(20), key = 'yaw_rate'), #184
    "L_AXIS_LEFT": partial(PressedFun, np.radians(20), key = 'yaw_rate'), #185
    "L_HAT_RIGHT": partial(PressedFun, np.radians(-20), key = 'yaw_rate'), #186
    "L_AXIS_RIGHT": partial(PressedFun, np.radians(-20), key = 'yaw_rate'), #187

    "TRIANGLE": partial(PressedFun, -0.15, key = 'height'), #189
    "CROSS": partial(PressedFun, 0.15, key = 'height'), #190
    "SQUARE": partial(PressedFun, 0.15, key = 'SQUARE'), #191
    "CIRCLE": partial(PressedFun, 0.15, key = 'CIRCLE'), #192

    "L1": partial(PressedFun, 0.015, key = 'pitch'), #194
    "L2": partial(PressedFun, -0.015, key = 'pitch'), #195
    "R1": partial(PressedFun, -0.15, key = 'x_shift'), #196
    "R2": partial(PressedFun, 0.15, key = 'x_shift'), #197
} #198

HOLD_ACTION_MAP_BUTTONS0 = { #200
    "TRIANGLE": partial(HoldFun, -0.15, key = 'height'), #201
    "CROSS": partial(HoldFun, 0.15, key = 'height'), #202
    "SQUARE": partial(HoldFun, 0.15, key = 'SQUARE'), #203
    "CIRCLE": partial(HoldFun, 0.15, key = 'CIRCLE'), #204

    "L1": partial(HoldFun, 0.015, key = 'pitch'), #206
    "L2": partial(HoldFun, -0.015, key = 'pitch'), #207
    "R1": partial(HoldFun, -0.15, key = 'x_shift'), #208
    "R2": partial(HoldFun, 0.15, key = 'x_shift'), #209
} #210
RELEASED_ACTION_MAP_BUTTONS0 = { #211
    "L_HAT_UP": partial(ReleaseFun, 0, key = 'x'), #212
    "L_AXIS_UP": partial(ReleaseFun, 0, key = 'x'), #213
    "L_HAT_DOWN": partial(ReleaseFun, 0, key = 'x'), #214
    "L_AXIS_DOWN": partial(ReleaseFun, 0, key = 'x'), #215
    "L_HAT_LEFT": partial(ReleaseFun, np.radians(0), key = 'yaw_rate'), #216
    "L_AXIS_LEFT": partial(ReleaseFun, np.radians(0), key = 'yaw_rate'), #217
    "L_HAT_RIGHT": partial(ReleaseFun, np.radians(0), key = 'yaw_rate'), #218
    "L_AXIS_RIGHT": partial(ReleaseFun, np.radians(0), key = 'yaw_rate'), #219
} #220

PRESSED_ACTION_MAP_BUTTONS = { #222
    "START": go_home, #223
    "SELECT": partial(PressedFun, 0, key = 'legs_coord'), #224

    "L_HAT_UP": partial(PressedFun, 1, key = 'x'), #226
    "L_AXIS_UP": partial(PressedFun, 1, key = 'x'), #227
    "L_HAT_DOWN": partial(PressedFun, -1, key = 'x'), #228
    "L_AXIS_DOWN": partial(PressedFun, -1, key = 'x'), #229
    "L_HAT_LEFT": partial(PressedFun, np.radians(20), key = 'yaw_rate'), #230
    "L_AXIS_LEFT": partial(PressedFun, np.radians(20), key = 'yaw_rate'), #231
    "L_HAT_RIGHT": partial(PressedFun, np.radians(-20), key = 'yaw_rate'), #232
    "L_AXIS_RIGHT": partial(PressedFun, np.radians(-20), key = 'yaw_rate'), #233

    "TRIANGLE": partial(PressedFun, -0.15, key = 'height'), #235
    "CROSS": partial(PressedFun, 0.15, key = 'height'), #236
    "SQUARE": partial(PressedFun, 0.15, key = 'SQUARE'), #237
    "CIRCLE": partial(PressedFun, 0.15, key = 'CIRCLE'), #238

    "L1": partial(PressedFun, 0.015, key = 'pitch'), #240
    "L2": partial(PressedFun, -0.015, key = 'pitch'), #241
    "R1": partial(PressedFun, -0.15, key = 'x_shift'), #242
    "R2": partial(PressedFun, 0.15, key = 'x_shift'), #243
} #244

HOLD_ACTION_MAP_BUTTONS = { #246
    "TRIANGLE": partial(HoldFun, -0.15, key = 'height'), #247
    "CROSS": partial(HoldFun, 0.15, key = 'height'), #248
    "SQUARE": partial(HoldFun, 0.15, key = 'SQUARE'), #249
    "CIRCLE": partial(HoldFun, 0.15, key = 'CIRCLE'), #250

    "L1": partial(HoldFun, 0.015, key = 'pitch'), #252
    "L2": partial(HoldFun, -0.015, key = 'pitch'), #253
    "R1": partial(HoldFun, -0.15, key = 'x_shift'), #254
    "R2": partial(HoldFun, 0.15, key = 'x_shift'), #255
} #256
RELEASED_ACTION_MAP_BUTTONS = { #257
    "L_HAT_UP": partial(ReleaseFun, 0, key = 'x'), #258
    "L_AXIS_UP": partial(ReleaseFun, 0, key = 'x'), #259
    "L_HAT_DOWN": partial(ReleaseFun, 0, key = 'x'), #260
    "L_AXIS_DOWN": partial(ReleaseFun, 0, key = 'x'), #261
    "L_HAT_LEFT": partial(ReleaseFun, np.radians(0), key = 'yaw_rate'), #262
    "L_AXIS_LEFT": partial(ReleaseFun, np.radians(0), key = 'yaw_rate'), #263
    "L_HAT_RIGHT": partial(ReleaseFun, np.radians(0), key = 'yaw_rate'), #264
    "L_AXIS_RIGHT": partial(ReleaseFun, np.radians(0), key = 'yaw_rate'), #265
} #266


class Joystick: #269
    def __init__(self): #270
        os.environ["SDL_VIDEODRIVER"] = "dummy"  # For use PyGame without opening a visible display #271
        pg.display.init() #272

        self.js = None #274
        self.BUTTONS_NEW = None # Initialize button mapping. （初始化按键映射） #275
        self.last_buttons = None # Initialize button states. （初始化按键状态） #276
        self.hold_count = None # Initialize button hold counters. （初始化按键保持计数） #277
        self.lock = threading.Lock() #278
        self.speed_x = 0 #279
        self.speed_y = 0 #280

        # Initialize action mapping as empty; appropriate mapping will be selected after joystick is connected. （初始化动作映射为空，在连接手柄后会根据手柄类型选择合适的映射） #282
        self.PRESSED_ACTION_MAP = {} #283
        self.HOLD_ACTION_MAP = {} #284
        self.RELEASED_ACTION_MAP = {} #285

        threading.Thread(target=self.connect, daemon=True).start() #287

    def get_button_state(self,button): #289
        if self.BUTTONS_NEW is None: #290
            return False  # If joystick is not initialized, return False by default. （如果没有初始化手柄，默认返回False） #291
        return self.last_buttons[self.BUTTONS_NEW.index(button)] #292

    def connect(self): #294
        while True: #295
            if os.path.exists("/dev/input/js0"): #296
                with self.lock: #297
                    if self.js is None: #298
                        pg.joystick.init() #299
                        try: #300
                            self.js = pg.joystick.Joystick(0) #301
                            self.js.init() #302
                            joystick_name = self.js.get_name() #303
                            print(f"Joystick connected: {joystick_name}") #304
                            if joystick_name == 'SHANWAN Android Gamepad': #305
                                self.BUTTONS_NEW = BUTTONS0 #306
                                self.last_buttons = [0] * len(BUTTONS0) #307
                                self.hold_count = [0] * len(BUTTONS0) #308
                                # Select the action mapping corresponding to BUTTONS0. （选择BUTTONS0对应的动作映射） #309
                                self.PRESSED_ACTION_MAP = PRESSED_ACTION_MAP_BUTTONS0 #310
                                self.HOLD_ACTION_MAP = HOLD_ACTION_MAP_BUTTONS0 #311
                                self.RELEASED_ACTION_MAP = RELEASED_ACTION_MAP_BUTTONS0 #312
                            elif joystick_name == 'USB WirelessGamepad': #313
                                self.BUTTONS_NEW = BUTTONS #314
                                self.last_buttons = [0] * len(BUTTONS) #315
                                self.hold_count = [0] * len(BUTTONS) #316
                                # Select the action mapping corresponding to BUTTONS. （选择BUTTONS对应的动作映射） #317
                                self.PRESSED_ACTION_MAP = PRESSED_ACTION_MAP_BUTTONS #318
                                self.HOLD_ACTION_MAP = HOLD_ACTION_MAP_BUTTONS #319
                                self.RELEASED_ACTION_MAP = RELEASED_ACTION_MAP_BUTTONS #320
                            else: #321
                                print(f"Unknown joystick: {joystick_name}. Using default button mapping.") #322
                                self.BUTTONS_NEW = BUTTONS0 #323
                                self.last_buttons = [0] * len(BUTTONS0) #324
                                self.hold_count = [0] * len(BUTTONS0) #325
                                # Default to the BUTTONS0 action mapping. （默认选择BUTTONS0对应的动作映射） #326
                                self.PRESSED_ACTION_MAP = PRESSED_ACTION_MAP_BUTTONS0 #327
                                self.HOLD_ACTION_MAP = HOLD_ACTION_MAP_BUTTONS0 #328
                                self.RELEASED_ACTION_MAP = RELEASED_ACTION_MAP_BUTTONS0 #329
                            print("self.BUTTONS_NEW initialized:", self.BUTTONS_NEW) #330
                            print("self.last_buttons initialized:", self.last_buttons) #331
                            print("self.hold_count initialized:", self.hold_count) #332
                            print("Action maps initialized for:", joystick_name) # Print that the action mapping table has been initialized. （打印动作映射表已初始化） #333
                        except Exception as e: #334
                            print(f"Error initializing joystick: {e}") #335
                            self.js = None #336
                            self.BUTTONS_NEW = None #337
                            self.last_buttons = None #338
                            self.hold_count = None #339
                            self.PRESSED_ACTION_MAP = {} #340
                            self.HOLD_ACTION_MAP = {} #341
                            self.RELEASED_ACTION_MAP = {} #342
            else: #343
                with self.lock: #344
                    if self.js is not None: #345
                        self.js.quit() #346
                        self.js = None #347
                        self.BUTTONS_NEW = None #348
                        self.last_buttons = None #349
                        self.hold_count = None #350
                        self.PRESSED_ACTION_MAP = {} #351
                        self.HOLD_ACTION_MAP = {} #352
                        self.RELEASED_ACTION_MAP = {} #353
            time.sleep(0.2) #354

    def update_buttons(self): #356
        global enable_control #357
        with self.lock: #358
            if self.js is None or not enable_control or self.BUTTONS_NEW is None: #359
                return #360

            # update and read joystick data #362
            pg.event.pump() #363
            buttons = [self.js.get_button(i) for i in range(13)] # Pygame supports up to 13 standard buttons. （pygame 最多支持13个标准按钮） #364
            # print(buttons) #365
            hat = list(self.js.get_hat(0)) #366
            axis = [self.js.get_axis(i) for i in range(4)] #367
            hat.extend(axis) #368
            # convert analog data to digital #369
            for i in range(6): #370
                buttons.extend([1 if hat[i] < -0.5 else 0, 1 if hat[i] > 0.5 else 0]) #371
            # check what has changed in this update #372
            buttons = np.array(buttons) #373
            buttons_changed = np.bitwise_xor(self.last_buttons, buttons).tolist() #374
            self.last_buttons = buttons  # save buttons data #375

        # if chassis: #377
        #     axis[0] = hiwonder.misc.val_map(axis[0], -1, 1, -200, 200) #378
        #     axis[1] = hiwonder.misc.val_map(axis[1], -1, 1, 200, -200) #379
        #     axis[2] = hiwonder.misc.val_map(axis[2], -1, 1, 90, -90) #380
        #     v, d = chassis.translation(axis[0], axis[1], fake=True) #381
        #     chassis.set_velocity(v, d, axis[2]) #382

        for i, button in enumerate(buttons_changed): #384
            if button:  # button state changed #385
                if buttons[i]: #386
                    rospy.logdebug(self.BUTTONS_NEW[i] + " pressed") #387
                    self.hold_count[i] = 0 #388
                    button_name = self.BUTTONS_NEW[i] #389
                    if button_name in self.PRESSED_ACTION_MAP: #390
                        try: #391
                            self.PRESSED_ACTION_MAP[button_name]() #392
                        except Exception as e: #393
                                rospy.logerr(e) #394
                else: #395
                    rospy.logdebug(self.BUTTONS_NEW[i] + " released") #396
                    button_name = self.BUTTONS_NEW[i] #397
                    if button_name in self.RELEASED_ACTION_MAP: #398
                        try: #399
                            self.RELEASED_ACTION_MAP[button_name]() #400
                        except Exception as e: #401
                                rospy.logerr(e) #402
            else: #403
                if buttons[i]: #404
                    if self.hold_count[i] < 3:  # Better distinguish between short press and long press #405
                        self.hold_count[i] += 1 #406
                    else: #407
                        rospy.logdebug(self.BUTTONS_NEW[i] + " hold") #408
                        button_name = self.BUTTONS_NEW[i] #409
                        if button_name in self.HOLD_ACTION_MAP: #410
                            try: #411
                                self.HOLD_ACTION_MAP[button_name]() #412
                            except Exception as e: #413
                                rospy.logerr(e) #414

if __name__ == '__main__': #416

   #rospy.sleep(4)#等待参数加载完毕(wait for the parameters to load completely) #418
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.INFO) #419
    #PP = rospy.get_param('/puppy_control/PuppyPose') #420
    PuppyPose = Stand.copy() #421

    rospy.Subscriber('/puppy_control/legs_coord', Polygon, lambda msg:LegsCoordFun(msg)) #423
    buzzer_pub = rospy.Publisher('/ros_robot_controller/set_buzzer', BuzzerState, queue_size=1) #424

    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity/autogait', Velocity, queue_size=1) #426
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #427

    js = Joystick() #429

    while True: #431
        try: #432
            js.update_buttons() #433
            rospy.sleep(0.05) #434
            if rospy.is_shutdown(): #435
                sys.exit(0) #436
        except KeyboardInterrupt: #437
            sys.exit(0) #438
