#!/usr/bin/python3 #1
# coding=utf8 #2
# Author:Summer #3
# Email:997950600@qq.com #4

import os, sys, math #6
import numpy as np #7
import rospy #8
from std_msgs.msg import UInt8, UInt16, Float32, Float64, Bool, String,Float32MultiArray #9
from std_srvs.srv import Empty, SetBool #10
# from sensor_msgs.msg import Image #11
from geometry_msgs.msg import Point32, Polygon #12
from puppy_control.msg import Velocity, Pose, Gait #13
from puppy_control.srv import SetRunActionName #14
from geometry_msgs.msg import Twist #15

ROS_NODE_NAME = 'puppy_control' #17

sys.path.append('/home/ubuntu/software/puppypi_control') #19
from servo_controller import setServoPulse #20
from action_group_control import runActionGroup, stopActionGroup #21


class PUPPY(): #24
    def __init__(self): #25
        rospy.init_node("puppy_run_act", anonymous=True) #26
        rospy.Subscriber('/multi_robot/runActionGroup', String, self.runActionGroupFun) #27

    def runActionGroupFun(self, msg): #29
        rospy.logdebug(msg) #30
        print(msg) #31
        runActionGroup(msg.data, False) #32
        return [True, msg.data] #33


if __name__ == '__main__': #36
    puppy = PUPPY() #37

    try: #39
        rospy.spin() #40
    except : #41
        pass #42
    finally: #43
        pass #44
