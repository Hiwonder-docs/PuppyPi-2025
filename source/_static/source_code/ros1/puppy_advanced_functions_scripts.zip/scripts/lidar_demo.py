#!/usr/bin/python3 #1
# coding=utf8 #2

import math #4
import time #5
import rospy #6
import threading #7
import numpy as np #8
from std_msgs.msg import Float32 #9
import geometry_msgs.msg as geo_msg #10
import sensor_msgs.msg as sensor_msg #11
from ros_robot_controller.msg import BuzzerState #12

MAX_SCAN_ANGLE = 360 # 激光的扫描角度,去掉总是被遮挡的部分degree(the scanning angle of the laser, excluding the consistently obstructed portion, in degrees) #14

class LidarController: #16
    def __init__(self, name): #17
        rospy.init_node(name, anonymous=True) #18
        rospy.on_shutdown(self.cleanup) #19
        self.name = name #20
        self.running_mode = 1 # 1：雷达避障模式  2：雷达警卫模式，(1: Radar obstacle avoidance mode 2: Radar guard mode) #21
        self.threshold = 0.3 # meters  距离阈值(distance threshold) #22
        self.scan_angle = math.radians(90)  # radians  向前的扫描角度(the forward scanning angle) #23
        self.speed = 0.12 # 单位米，避障模式的速度(the speed in meters per second for obstacle avoidance mode) #24
        self.last_act = 0 #25
        self.timestamp = 0 #26
        self.lock = threading.RLock() #27
        self.lidar_sub = None #28
        self.velocity_pub = rospy.Publisher('/cmd_vel_nav', geo_msg.Twist, queue_size=1) #29
        self.velocity_pub.publish(geo_msg.Twist()) #30
        self.lidar_sub = rospy.Subscriber('/scan', sensor_msg.LaserScan, self.lidar_callback)  #31
        self.buzzer_pub = rospy.Publisher('/ros_robot_controller/set_buzzer', BuzzerState, queue_size=1) #32
        self.buzzer_pub.publish(0.1) #33
        
    def lidar_callback(self, lidar_data:sensor_msg.LaserScan): #35
        twist = geo_msg.Twist() #36
        max_index = int(math.radians(MAX_SCAN_ANGLE / 2.0) / lidar_data.angle_increment) #37
        left_ranges = lidar_data.ranges[:max_index] #38
        right_ranges = lidar_data.ranges[::-1][:max_index] #39
        
        with self.lock: #41
            #angle = math.atan(self.car_width / self.threshold) #42
            angle = self.scan_angle / 2 #43
            angle_index = int(angle / lidar_data.angle_increment + 0.50) #44
            
            left_ranges, right_ranges = left_ranges[:angle_index], right_ranges[:angle_index] #46
            
            if self.running_mode == 1 and self.timestamp <= time.time(): #48
                min_index_left, min_index_right = np.nanargmin(np.array(left_ranges)),  np.nanargmin(np.array(right_ranges)) #49
                min_dist_left, min_dist_right = left_ranges[min_index_left], right_ranges[min_index_right] #50
                angle_left = lidar_data.angle_increment * min_index_left #51
                angle_right = lidar_data.angle_increment * min_index_right #52
                # print(min_dist_left, min_dist_right) #53
                if min_dist_left <= self.threshold and min_dist_right > self.threshold: # 左侧有障碍(there is an obstacle on the left side) #54
                    twist.linear.x = self.speed / 6 #55
                    max_angle = math.radians(90) #56
                    w = self.speed * 3 #57
                    twist.angular.z = -w #58
                    self.velocity_pub.publish(twist) #59
                    self.timestamp = time.time() + (max_angle / w / 2) #60
                elif min_dist_left <= self.threshold and min_dist_right <= self.threshold: # 两侧都有障碍(there are obstacles on both sides) #61
                    twist.linear.x = self.speed / 6 #62
                    w = self.speed * 3 #63
                    twist.angular.z = w #64
                   
                    self.velocity_pub.publish(twist) #66
                    self.timestamp = time.time() + (math.radians(30) / w / 2) #67
                elif min_dist_left > self.threshold and min_dist_right <= self.threshold: # 右侧有障碍(there is an obstacle on the right side) #68
                    twist.linear.x = self.speed / 6 #69
                    max_angle = math.radians(90) #70
                    w = self.speed * 3 #71
                    twist.angular.z = w #72
                    
                    self.velocity_pub.publish(twist) #74
                    self.timestamp = time.time() + (max_angle / w /2) #75
                else: # 没有障碍(there are no obstacles) #76
                    self.last_act = 0 #77
                    twist.linear.x = self.speed #78
                    twist.angular.z = 0 #79
                    self.velocity_pub.publish(twist) #80

            elif self.running_mode == 2: #82
                min_index_left, min_index_right = np.nanargmin(np.array(left_ranges)),  np.nanargmin(np.array(right_ranges)) #83
                min_dist_left, min_dist_right = left_ranges[min_index_left], right_ranges[min_index_right] #84
                if min_dist_left <= self.threshold or min_dist_right <= self.threshold: # 检测到障碍(the obstacle is detected) #85
                    self.buzzer_pub.publish(0.1) #86

    def cleanup(self): #88
       
        self.lidar_sub.unregister() #90
        self.velocity_pub.publish(geo_msg.Twist()) #91
        print('is_shutdown') #92


if __name__ == "__main__": #95
    node = LidarController('lidar_demo') #96
    try: #97
        rospy.spin() #98
    except Exception as e: #99
        rospy.logerr(str(e)) #100
