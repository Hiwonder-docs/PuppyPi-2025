#!/usr/bin/python3 #1
# coding=utf8 #2
# Date:2022/4/7 #3
# Author:hiwonder #4
import sys #5
import cv2 #6
import time #7
import math #8
import threading #9
import numpy as np #10
from enum import Enum #11
from common import Misc #12

import rospy #14
from std_srvs.srv import * #15
from sensor_msgs.msg import Image #16
from object_tracking.srv import * #17
from puppy_control.msg import Velocity, Pose, Gait #18

ROS_NODE_NAME = 'obstacle_detect_demo' #20

PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #22


if sys.version_info.major == 2: #25
    print('Please run this program with python3!') #26
    sys.exit(0) #27


__isRunning = True #30
__target_color = ('red',) #31

trend = 'left' # 遇到障碍物后，判断后续巡线方向的趋势，如果趋势向左，那么小狗向左绕开。如果趋势向右，那么小狗向右绕开(after encountering an obstacle, assess the trend of the following line-following direction. If the trend is towards the left, the robot dog navigates to the left to avoid it. If the trend is towards the right, the robot dog navigates to the right to avoid it) #33
area_max = 0 #34

class PuppyStatus(Enum): #36
    NORMAL = 0 # 正常前进中(continuing forward) #37
    FOUND_TARGET = 3 # 已经发现目标障碍物(target obstacle detected) #38
    STOP = 10 #39
    END = 20             #40

puppyStatus = PuppyStatus.NORMAL #42
puppyStatusLast = PuppyStatus.END #43



color_range_list = rospy.get_param('/lab_config_manager/color_range_list') #47

# 找出面积最大的轮廓(find out the contour with the maximal area) #49
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #50
def getAreaMaxContour(contours): #51
    contour_area_temp = 0 #52
    contour_area_max = 0 #53
    area_max_contour = None #54

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #56
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #57
        if contour_area_temp > contour_area_max: #58
            contour_area_max = contour_area_temp #59
            if contour_area_temp >= 5:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than 50, the contour with the largest area is considered valid to filter out interference) #60
                area_max_contour = c #61

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the maximal contour) #63


line_centerx = -1 #66
img_centerx = 320 #67
def move(): #68
    global line_centerx, puppyStatus, puppyStatusLast #69
    
    while True: #71
        if __isRunning: #72
            while(puppyStatus == PuppyStatus.NORMAL) : #73
                if area_max > 70000: # 路桩或障碍物已经在眼前了，已经发现目标，要开始启动避开程序(the road post or obstacle is now in sight, and the target has been detected. It's time to initiate the avoidance program) #74
                    puppyStatus = PuppyStatus.FOUND_TARGET #75
                    break #76
                if line_centerx != -1: #77
                    if abs(line_centerx - img_centerx) <= 50: #78
                        PuppyMove['x'] = 10 #79
                        PuppyMove['yaw_rate'] = math.radians(0) #80
                    elif line_centerx - img_centerx > 50: #81
                        PuppyMove['x'] = 8 #82
                        PuppyMove['yaw_rate'] = math.radians(-15) #83
                    elif line_centerx - img_centerx < -50: #84
                        PuppyMove['x'] = 8 #85
                        PuppyMove['yaw_rate'] = math.radians(15) #86
                    PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #87
                break #88
            while(puppyStatus == PuppyStatus.FOUND_TARGET) : #89
                signal = 1 if trend == 'left' else -1 #90
                
                PuppyMove['x'] = 0 #92
                PuppyMove['yaw_rate'] = math.radians(15 * signal) #93
                PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #94
                # 开始原地转向，绕开目标物体(begin turning in place to navigate around the target object) #95
                print('开始原地转向1') #96
                time.sleep(2) #97
                area_max_times = 0 #98
                t = time.time() #99
                while time.time() - t < 5: #100
                    if area_max < 5000: #101
                        area_max_times += 1 #102
                        print('area_max',area_max) #103
                    if area_max_times >= 3: #104
                        break # 目标物体已经基本离开视野(the target object is almost out of sight) #105
                    time.sleep(0.1) #106
                time.sleep(1) #107
                print('完成原地转向，绕开目标物体',time.time() - t) #108


                PuppyMove['x'] = 10 #111
                PuppyMove['yaw_rate'] = math.radians(-3 * signal) #112
                PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #113
                print('开始直行2') #114
                time.sleep(7)# 直行一段时间(continue straight for a while) #115
                print('完成直行一段时间') #116

                PuppyMove['x'] = 7 #118
                PuppyMove['yaw_rate'] = math.radians(-9 * signal) #119
                PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #120
                # 前面已经绕开目标物体，现在开始回来寻找直线(having circumvented the target object ahead, it's time to return and search for the straight line) #121
                time.sleep(2) #122
                print('开始3') #123
                area_max_times = 0 #124
                t = time.time() #125
                while time.time() - t < 6: #126
                    if area_max > 5000: #127
                        
                        print('area_max',area_max) #129
                        break # 目标物体已经基本离开视野(the target object has mostly left the field of view) #130
                    time.sleep(0.1) #131
                print('完成寻找直线',time.time() - t) #132
                print('结束') #133
                # puppy.move_stop(servo_run_time = 100) #134
                # time.sleep(0.1) #135
                puppyStatus = PuppyStatus.NORMAL #136
                break #137
            time.sleep(0.02) #138
        else: #139
            PuppyMove['x'] = 0 #140
            PuppyMove['yaw_rate'] = math.radians(0) #141
            PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate = PuppyMove['yaw_rate']) #142
            time.sleep(0.02) #143

        if puppyStatusLast != puppyStatus: #145
            print('puppyStatus',puppyStatus) #146
        puppyStatusLast = puppyStatus #147

# 运行子线程(run sub-thread) #149
th = threading.Thread(target=move) #150
th.setDaemon(True) #151
# th.start() #152

# roi = [ # [ROI, weight] #154
#         (0, 40,  0, 640, 0.1),  #155
#         (80, 120,  0, 640, 0.2),  #156
#         (160, 200,  0, 640, 0.7) #157
#        ] #158
roi = [ # [ROI, weight] #159
        (240, 280,  0, 640, 0.1),  #160
        (320, 360,  0, 640, 0.2),  #161
        (400, 440,  0, 640, 0.7) #162
       ] #163

roi_h1 = roi[0][0] #165
roi_h2 = roi[1][0] - roi[0][0] #166
roi_h3 = roi[2][0] - roi[1][0] #167

roi_h_list = [roi_h1, roi_h2, roi_h3] #169

size = (640, 480) #171
def run(img): #172
    global line_centerx #173
    global __target_color, __isRunning, puppyStatus, trend, area_max #174
    
    img_copy = img.copy() #176
    img_h, img_w = img.shape[:2] #177
    
#     cv2.line(img, (int(img_w/2), 0), (int(img_w/2), img_h), (255, 0, 255), 2) #179
    
    if not __isRunning or __target_color == (): #181
        return img #182
    
    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #184
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #185
            
    centroid_x_sum = 0 #187
    weight_sum = 0 #188
    center_ = [] #189
    n = 0 #190

    #将图像分割成上中下三个部分，这样处理速度会更快，更精确(Dividing the image into upper, middle, and lower parts, which will result in faster and more accurate processing) #192
    for r in roi: #193
        roi_h = roi_h_list[n] #194
        n += 1        #195
        blobs = frame_gb[r[0]:r[1], r[2]:r[3]] #196
        frame_lab = cv2.cvtColor(blobs, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #197
        
        # area_max = 0 #199
        areaMaxContour = 0 #200
        for i in color_range_list: #201
            if i in __target_color: #202
                detect_color = i #203
                
                frame_mask = cv2.inRange(frame_lab, #205
                                             (color_range_list[detect_color]['min'][0], #206
                                              color_range_list[detect_color]['min'][1], #207
                                              color_range_list[detect_color]['min'][2]), #208
                                             (color_range_list[detect_color]['max'][0], #209
                                              color_range_list[detect_color]['max'][1], #210
                                              color_range_list[detect_color]['max'][2]))  #对原图像和掩模进行位运算(perform operation to original image and mask) #211
                opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((6, 6), np.uint8))  # 开运算(opening operation) #212
                closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((6, 6), np.uint8))  # 闭运算(closing operation) #213
        #closed[:, 0:160] = 0 #214
        #closed[:, 480:640] = 0         #215
        cnts = cv2.findContours(closed , cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2]#找出所有轮廓(find out all the contours) #216
        cnt_large, area = getAreaMaxContour(cnts)#找到最大面积的轮廓(find out the contour with the maximal area) #217
        
        if cnt_large is not None:#如果轮廓不为空(if contour is not none) #219
            rect = cv2.minAreaRect(cnt_large)#最小外接矩形(the minimum bounding rectangle) #220
            box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #221
            for i in range(4): #222
                box[i, 1] = box[i, 1] + (n - 1)*roi_h + roi[0][0] #223
                box[i, 1] = int(Misc.map(box[i, 1], 0, size[1], 0, img_h)) #224
            for i in range(4):                 #225
                box[i, 0] = int(Misc.map(box[i, 0], 0, size[0], 0, img_w)) #226
                
            cv2.drawContours(img, [box], -1, (0,0,255,255), 2)#画出四个点组成的矩形(draw a rectangle formed by connecting the four points) #228
            
            #获取矩形的对角点(obtain the diagonal points of the rectangle) #230
            pt1_x, pt1_y = box[0, 0], box[0, 1] #231
            pt3_x, pt3_y = box[2, 0], box[2, 1]             #232
            center_x, center_y = (pt1_x + pt3_x) / 2, (pt1_y + pt3_y) / 2#中心点(center point) #233
            cv2.circle(img, (int(center_x), int(center_y)), 5, (0,0,255), -1)#画出中心点(draw out the center point) #234
            if n == 1: #235
                first_point_x = center_x #236
            center_.append([center_x, center_y])                         #237
            #按权重不同对上中下三个中心点进行求和(summing up the three central points of the top, middle, and bottom with different weights) #238
            centroid_x_sum += center_x * r[4] #239
            weight_sum += r[4] #240

    if puppyStatus == PuppyStatus.NORMAL or puppyStatus == PuppyStatus.FOUND_TARGET or puppyStatus == PuppyStatus.AVOID_TARGET: #242
        frame_lab_all = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #243
        frame_mask = cv2.inRange(frame_lab_all, #244
                                                (color_range_list[detect_color]['min'][0], #245
                                                color_range_list[detect_color]['min'][1], #246
                                                color_range_list[detect_color]['min'][2]), #247
                                                (color_range_list[detect_color]['max'][0], #248
                                                color_range_list[detect_color]['max'][1], #249
                                                color_range_list[detect_color]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #250
        opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((6, 6), np.uint8))  # 开运算(opening operation) #251
        closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((6, 6), np.uint8))  # 闭运算(closing operation) #252
        cnts = cv2.findContours(closed , cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2]#找出所有轮廓(find out all the contours) #253
        cnt_large, area_max = getAreaMaxContour(cnts)#找到最大面积的轮廓(find out the contour with the maximal area) #254
        # print('area',area) #255
        


    if weight_sum is not 0: #259
        #求最终得到的中心点(calculate the final resulting center point) #260
        cv2.circle(img, (line_centerx, int(center_y)), 10, (0,255,255), -1)#画出中心点(draw the center point) #261
        line_centerx = int(centroid_x_sum / weight_sum)   #262

        if puppyStatus == PuppyStatus.NORMAL: #264
            try: #265
                if first_point_x - line_centerx < 0: trend = 'left' #266
                else: trend = 'right' #267
            except:pass #268
    else: #269
        line_centerx = -1 #270

    return img #272

def image_callback(ros_image): #274
    # global lock #275
    
    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #277
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customize image information to image) #278
    cv2_img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #279
    
    frame = cv2_img.copy() #281
    frame_result = frame #282
    # with lock: #283
    if __isRunning: #284
        frame_result = run(frame) #285
        cv2.imshow('Frame', frame_result) #286
        key = cv2.waitKey(1) #287

    # rgb_image = cv2.cvtColor(frame_result, cv2.COLOR_BGR2RGB).tobytes() #289
    # ros_image.data = rgb_image #290
    # image_pub.publish(ros_image) #291

def cleanup(): #293
    PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #294
    print('is_shutdown') #295
if __name__ == '__main__': #296



    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #300
    rospy.on_shutdown(cleanup) #301

    PP = rospy.get_param('/puppy_control/PuppyPose') #303
    PuppyPose = PP['LookDown_20deg'].copy() #304
    PG = rospy.get_param('/puppy_control/GaitConfig') #305
    GaitConfig = PG['GaitConfigFast'].copy() #306

    image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #308

    image_pub = rospy.Publisher('/%s/image_result'%ROS_NODE_NAME, Image, queue_size=1)  # register result image publisher #310


    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #313
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #314
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #315

    rospy.sleep(0.5) #317
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #318
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #319
    
    rospy.sleep(0.2) #321
    PuppyGaitConfigPub.publish(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #322
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #323
    rospy.sleep(0.2) #324

    th.start() #326

    try: #328
        rospy.spin() #329
    except KeyboardInterrupt: #330
        print("Shutting down") #331
    finally: #332
        cv2.destroyAllWindows() #333
        
