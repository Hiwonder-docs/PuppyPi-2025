#!/usr/bin/python3 #1
# coding=utf8 #2
# 第7章 ROS机器狗创意课程\5.机身自平衡(7.ROS Robot Creative Course\5.Robot Self-balancing) #3
import sys #4
import cv2 #5
import math #6
import rospy #7
import threading #8
import numpy as np #9
from threading import RLock, Timer #10

from std_srvs.srv import * #12

from puppy_control.msg import Velocity, Pose, Gait #14
from sensor_msgs.msg import Imu #15


ROS_NODE_NAME = 'self_balancing_demo' #18


Stand = {'roll':math.radians(0), 'pitch':math.radians(0), 'yaw':0.000, 'height':-10, 'x_shift':-0.5, 'stance_x':0, 'stance_y':0} #21
PuppyPose = Stand.copy() #22


class MPU6050(): #25

    def __init__(self): #27
        rospy.Subscriber('/ros_robot_controller/imu_raw', Imu, self.GetImuFun) #28
        self.data = {'accel':[0,0,0], 'gyro':[0,0,0]} #29
        self.SecondOrderFilterX = self._SecondOrderFilter() #30
        self.SecondOrderFilterY = self._SecondOrderFilter() #31
        
    def GetImuFun(self,msg): #33
        self.data['accel'][0] = msg.linear_acceleration.x #34
        self.data['accel'][1] = msg.linear_acceleration.y #35
        self.data['accel'][2] = msg.linear_acceleration.z #36
        self.data['gyro'][0] = msg.angular_velocity.x #37
        self.data['gyro'][1] = msg.angular_velocity.y #38
        self.data['gyro'][2] = msg.angular_velocity.z #39


    def _SecondOrderFilter(self): #42
        # 二阶滤波算法(the second-order filtering algorithm) #43
        x1=0 #44
        x2=0 #45
        y1=0 #46
        angle = 0 #47
        K2 =0.02 #48
        def fun( angle_m, gyro_m, dt = 0.01): #49
            nonlocal x1 #50
            nonlocal x2 #51
            nonlocal y1 #52
            nonlocal angle #53
            nonlocal K2 #54
            x1=(angle_m-angle)*(1-K2)*(1-K2) #55
            y1=y1+x1*dt #56
            x2=y1+2*(1-K2)*(angle_m-angle)+gyro_m #57
            angle=angle+ x2*dt #58
            return angle #59

        return fun #61

    def get_euler_angle(self, dt = 0.01): #63
        # data = self.get_all_data() #64
        data = self.data #65
        accel_Y = math.atan2(data['accel'][0],data['accel'][2])*180/math.pi #66
        gyro_Y = data['gyro'][1] #67
        angleY = self.SecondOrderFilterY(-accel_Y,gyro_Y,dt) #68

        accel_X = math.atan2(data['accel'][1],data['accel'][2])*180/math.pi #70
        gyro_X = data['gyro'][0] #71
        angleX = self.SecondOrderFilterX(accel_X,gyro_X,dt) #72

        # return {'pitch':0, 'roll':0, 'yaw':0} #74
        return {'pitch':-math.radians(angleX), 'roll':-math.radians(angleY), 'yaw':0} #75



if __name__ == '__main__': #79
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #80
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #81
    mpu = MPU6050() #82
    rospy.sleep(0.2) #83
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #84
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #85
    
    rospy.sleep(0.2) #87
    
    debug = False #89

    rate = rospy.Rate(100)#100Hz 0.01s #91
    try: #92
        while not rospy.is_shutdown(): #93
            angle = mpu.get_euler_angle() #94
            print(angle) # 弧度(radians) #95
            if debug == False: #96
                PuppyPose['pitch'] = -angle['pitch']*1.8 #97
                PuppyPose['roll'] = angle['roll']*1.8 #98
                PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #99
                    ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw']) #100
            rate.sleep() #101

    except KeyboardInterrupt: #103
        print("Shutting down") #104
    finally: #105
        cv2.destroyAllWindows() #106
