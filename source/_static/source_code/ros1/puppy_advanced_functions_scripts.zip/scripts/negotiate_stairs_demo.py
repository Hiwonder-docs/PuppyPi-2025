#!/usr/bin/python3 #1
# coding=utf8 #2
# 第7章 ROS机器狗创意课程\2.AI识别台阶攀爬(7.ROS Robot Creative Lesson\2.AI Recognition Stair Climbing) #3

import sys #5
import cv2 #6
import time #7
import math #8
import threading #9
import numpy as np #10
from enum import Enum #11

from common import Misc #13

import rospy #15
from std_srvs.srv import * #16
from sensor_msgs.msg import Image #17
from object_tracking.srv import * #18
from puppy_control.msg import Velocity, Pose, Gait #19
from puppy_control.srv import SetRunActionName #20

ROS_NODE_NAME = 'negotiate_stairs_demo' #22

is_shutdown = False #24

color_range_list = rospy.get_param('/lab_config_manager/color_range_list') #26

PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #28


if sys.version_info.major == 2: #31
    print('Please run this program with python3!') #32
    sys.exit(0) #33

lock = threading.Lock() #35
debug = False #36
__isRunning = True #37
haved_detect = False #38

class PuppyStatus(Enum): #40
    LOOKING_FOR = 0 #寻找 低头寻找台阶，(search, lowering the head to look for stairs) #41

    FOUND_TARGET = 3 # 已经发现台阶目标(the target stair has been found) #43
    DOWN_STAIRS = 4 # 下台阶(go down the stair) #44

    STOP = 10 #46
    END = 20             #47

puppyStatus = PuppyStatus.LOOKING_FOR #49
puppyStatusLast = PuppyStatus.END #50



target_centre_point = None # 目标中心点坐标(the coordinates of the target center point) #54

range_rgb = { #56
    'red': (0, 0, 255), #57
    'blue': (255, 0, 0), #58
    'green': (0, 255, 0), #59
    'black': (0, 0, 0), #60
    'white': (255, 255, 255), #61
} #62

color_list = [] #64
detect_color = 'None' #65
action_finish = True #66
draw_color = range_rgb["black"] #67
__target_color = ('red',) #68


# 找出面积最大的轮廓(find out the contour with the maximal area) #71
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #72
def getAreaMaxContour(contours): #73
    contour_area_temp = 0 #74
    contour_area_max = 0 #75
    area_max_contour = None #76

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #78
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate the contour area) #79
        if contour_area_temp > contour_area_max: #80
            contour_area_max = contour_area_temp #81
            if contour_area_temp >= 5:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than 50, the contour with the largest area is considered valid to filter out interference) #82
                area_max_contour = c #83
    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the maximal contour) #84


def move(): #87
    global detect_color #88
    global puppyStatus, puppyStatusLast, haved_detect, action_finish, target_centre_point, PuppyPose #89
    up_stairs_time = 0 #90
    rospy.sleep(2) #91
    while True: #92
        rospy.sleep(0.01) #93

        while(puppyStatus == PuppyStatus.LOOKING_FOR) : #95
            if target_centre_point != None and target_centre_point[1] > 400: #96
                puppyStatus = PuppyStatus.FOUND_TARGET #97
                rospy.sleep(2.1) # 继续往前走一点(continue walking forward) #98
                PuppyVelocityPub.publish(x=0, y=0, yaw_rate = math.radians(0)) #99
                up_stairs_time = time.time() #100
                break #101
            
            PuppyVelocityPub.publish(x=10, y=0, yaw_rate = math.radians(0)) #103
            
            rospy.sleep(0.01) #105
            break #106
        
        while(puppyStatus == PuppyStatus.FOUND_TARGET) : #108
            runActionGroup_srv('up_stairs_2cm.d6ac',True) #109
            if time.time() - up_stairs_time > 25: #110
                puppyStatus = PuppyStatus.DOWN_STAIRS #111
                PuppyPose = PP['Stand'].copy() #112
                PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #113
                    ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #114
                rospy.sleep(0.5) #115
            break #116

        while(puppyStatus == PuppyStatus.DOWN_STAIRS) : #118
            PuppyVelocityPub.publish(x=14, y=0, yaw_rate = math.radians(0)) #119
            rospy.sleep(0.1) #120
            break #121

        if puppyStatusLast != puppyStatus: #123
            print('puppyStatus',puppyStatus) #124
        puppyStatusLast = puppyStatus #125

        if is_shutdown:break #127

# 运行子线程(run sub-thread) #129
th = threading.Thread(target=move) #130
th.setDaemon(True) #131
# th.start() #132


size = (320, 240) #135

def run(img): #137
    global line_centerx #138
    global __target_color, __isRunning, puppyStatus, target_centre_point, area_max #139
    
    img_h, img_w = img.shape[:2] #141

    frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #143
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #144
            

    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #147

    for i in color_range_list: #149
        if i in __target_color: #150
            detect_color = i #151
            
            frame_mask = cv2.inRange(frame_lab, #153
                                            (color_range_list[detect_color]['min'][0], #154
                                            color_range_list[detect_color]['min'][1], #155
                                            color_range_list[detect_color]['min'][2]), #156
                                            (color_range_list[detect_color]['max'][0], #157
                                            color_range_list[detect_color]['max'][1], #158
                                            color_range_list[detect_color]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #159
            opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((6, 6), np.uint8))  # 开运算(opening operation) #160
            closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((6, 6), np.uint8))  # 闭运算(closing operation) #161
         
    cnts = cv2.findContours(closed , cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2]#找出所有轮廓(find out all the contours) #163
    cnt_large, area_max = getAreaMaxContour(cnts)#找到最大面积的轮廓(find out the contour with the maximal area) #164
    
    if cnt_large is not None:#如果轮廓不为空(if contour is not none) #166
        rect = cv2.minAreaRect(cnt_large)#最小外接矩形(the minimum bounding rectangle) #167
        box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #168
        
        centerX = rect[0][0] #170
        centerY = rect[0][1] #171
        centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #172
        centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #173
        for i in range(4): #174
            box[i, 1] = int(Misc.map(box[i, 1], 0, size[1], 0, img_h)) #175
        for i in range(4):                 #176
            box[i, 0] = int(Misc.map(box[i, 0], 0, size[0], 0, img_w)) #177
            
        cv2.drawContours(img, [box], -1, (0,0,255,255), 2)#画出四个点组成的矩形(draw a rectangle formed by the four points) #179
        target_centre_point = [centerX, centerY]       #180
        cv2.circle(img, (int(centerX), int(centerY)), 5, (0,0,255), -1)#画出中心点(draw the center point) #181

            
    return img #184


def image_callback(ros_image): #187
    
    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #189
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customize image information to image) #190
    cv2_img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #191
    
    frame = cv2_img.copy() #193
    frame_result = frame #194
   
    if __isRunning: #196
        frame_result = run(frame) #197
        if puppyStatus != PuppyStatus.FOUND_TARGET: #198
            cv2.imshow('Frame', frame_result) #199
            key = cv2.waitKey(1) #200
        rospy.sleep(0.001) #201

def cleanup(): #203
    global is_shutdown #204
    is_shutdown = True #205
    PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #206
    print('is_shutdown') #207

if __name__ == '__main__': #209
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #210
    rospy.on_shutdown(cleanup) #211

    PP = rospy.get_param('/puppy_control/PuppyPose') #213
    PuppyPose = PP['LookDown_10deg'].copy() #214
    PG = rospy.get_param('/puppy_control/GaitConfig') #215
    GaitConfig = PG['GaitConfigFast'].copy() #216

    image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #218

    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #220
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #221
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #222

    runActionGroup_srv = rospy.ServiceProxy('/puppy_control/runActionGroup', SetRunActionName) #224

    rospy.sleep(0.5) #226
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #227
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #228
    
    rospy.sleep(0.2) #230
    PuppyGaitConfigPub.publish(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #231
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #232
    rospy.sleep(0.2) #233
    
    debug = False #235
    if debug == False: #236
        th.start() #237

    try: #239
        rospy.spin() #240
    except KeyboardInterrupt: #241
        print("Shutting down") #242
    finally: #243
        cv2.destroyAllWindows() #244

