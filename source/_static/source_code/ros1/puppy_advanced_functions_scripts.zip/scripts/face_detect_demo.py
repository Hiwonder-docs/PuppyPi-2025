#!/usr/bin/python3 #1
# coding=utf8 #2

# 第7章 ROS机器狗创意课程\1.AI视觉人脸检测\第2课 人脸检测(7. ROS Robot Creative Lesson\1. AI Visual Face Detection\Lesson 2 Face Detection) #4
import sys #5
import cv2 #6
import math #7
import rospy #8
import threading #9
import numpy as np #10
from threading import RLock, Timer #11
import mediapipe as mp #12
from std_srvs.srv import * #13
from sensor_msgs.msg import Image #14

from puppy_control.srv import SetRunActionName #16


ROS_NODE_NAME = 'face_detect_demo' #19



face = mp.solutions.face_detection #23
face_detection = face.FaceDetection(min_detection_confidence=0.6) #24

__isRunning = False #26

org_image_sub_ed = False #28
lock = RLock() #29


range_rgb = { #32
    'red': (0, 0, 255), #33
    'blue': (255, 0, 0), #34
    'green': (0, 255, 0), #35
    'black': (0, 0, 0), #36
    'white': (255, 255, 255), #37
} #38

# 初始位置(initial position) #40
def initMove(delay=False): #41
    runActionGroup_srv('sit.d6ac',False) #42
    with lock: #43
        pass #44
    if delay: #45
        rospy.sleep(2) #46

d_pulse = 5 #48
have_move = False #49
start_greet = False #50
action_finish = True #51
# 变量重置(variable reset) #52
def reset(): #53
    global d_pulse #54
    global have_move        #55
    global start_greet #56
    global action_finish  #57

    with lock: #59
        d_pulse = 5 #60
        have_move = False #61
        start_greet = False #62

# app初始化调用(app initialization calling) #64
def init(): #65
    print("face detect Init") #66
    initMove() #67
    reset() #68

def move(): #70
    global have_move #71
    global start_greet #72
    global action_finish  #73
    global d_pulse, servo6_pulse  #74
        
    while True: #76
        if __isRunning: #77
            if start_greet: #78
                start_greet = False                 #79
                action_finish = False #80

                runActionGroup_srv('shake_hands.d6ac',True) #82
                action_finish = True #83
                have_move = True #84
            else: #85
                if have_move: #86
                    have_move = False #87
                    rospy.sleep(0.2) #88

                rospy.sleep(0.05)                 #90
        else: #91
            rospy.sleep(0.01) #92
            
# 运行子线程(run sub-thread) #94
th = threading.Thread(target=move) #95
th.daemon = True #96
th.start() #97

frame_pass = True #99
def run(img): #100
    global frame_pass #101
    global start_greet #102

    img_copy = img.copy() #104
    img_h, img_w = img.shape[:2] #105
    
    if frame_pass: #107
        frame_pass = False #108
        return img #109
    
    frame_pass = True #111

    image_rgb = cv2.cvtColor(img_copy,cv2.COLOR_BGR2RGB) #113
    results = face_detection.process(image_rgb) #114
    if results.detections: #115
        for index, detection in enumerate(results.detections): #116
            bboxC = detection.location_data.relative_bounding_box #117
            bbox = (int(bboxC.xmin * img_w),int(bboxC.ymin * img_h), #118
                    int(bboxC.width * img_w),int(bboxC.height * img_h))  #119
        cv2.rectangle(img,bbox,(0,255,0),2) #120
        x,y,w,h = bbox #121
        center_x = int(x + (w/2)) #122
        if action_finish and abs(center_x - img_w/2) < 100: #123
            start_greet = True       #124
    return img #125

def image_callback(ros_image): #127
    global lock #128
    
    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #130
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customize image information to image) #131
    cv2_img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #132
    
    frame = cv2_img.copy() #134
    frame_result = frame #135
    with lock: #136
        if __isRunning: #137
            frame_result = run(frame) #138
    cv2.imshow('image', frame_result) #139
    cv2.waitKey(1) #140
    
def enter_func(msg): #142
    global lock #143
    global image_sub #144
    global __isRunning #145
    global org_image_sub_ed #146

    rospy.loginfo("enter face detect") #148
    with lock: #149
        init() #150
        if not org_image_sub_ed: #151
            org_image_sub_ed = True #152
            image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #153
            
    return [True, 'enter'] #155

heartbeat_timer = None #157
def exit_func(msg): #158
    global lock #159
    global image_sub #160
    global __isRunning #161
    global org_image_sub_ed #162
    
    rospy.loginfo("exit face detect") #164
    with lock: #165
        __isRunning = False #166
        try: #167
            if org_image_sub_ed: #168
                org_image_sub_ed = False #169
                if heartbeat_timer:heartbeat_timer.cancel() #170
                image_sub.unregister() #171
        except: #172
            pass #173
    
    return [True, 'exit'] #175

def start_running(): #177
    global lock #178
    global __isRunning #179

    rospy.loginfo("start running face detect") #181
    with lock: #182
        __isRunning = True #183

def stop_running(): #185
    global lock #186
    global __isRunning #187

    rospy.loginfo("stop running face detect") #189
    with lock: #190
        __isRunning = False #191
        reset() #192
        initMove(delay=False) #193

def set_running(msg): #195
    if msg.data: #196
        start_running() #197
    else: #198
        stop_running() #199
    
    return [True, 'set_running'] #201

def heartbeat_srv_cb(msg): #203
    global heartbeat_timer #204
    
    if isinstance(heartbeat_timer, Timer): #206
        heartbeat_timer.cancel() #207
    if msg.data: #208
        heartbeat_timer = Timer(5, rospy.ServiceProxy('/face_detect/exit', Trigger)) #209
        heartbeat_timer.start() #210
    rsp = SetBoolResponse() #211
    rsp.success = msg.data #212

    return rsp #214

if __name__ == '__main__': #216
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.DEBUG) #217
    

    image_pub = rospy.Publisher('/%s/image_result'%ROS_NODE_NAME, Image, queue_size=1)  # register result image publisher #220

    runActionGroup_srv = rospy.ServiceProxy('/puppy_control/runActionGroup', SetRunActionName) #222

    debug = True #224
    if debug: #225
        enter_func(1) #226
        start_running() #227
    
    try: #229
        rospy.spin() #230
    except KeyboardInterrupt: #231
        print("Shutting down") #232
    finally: #233
        cv2.destroyAllWindows() #234
