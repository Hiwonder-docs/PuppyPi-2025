#!/usr/bin/python3 #1
# coding=utf8 #2
# 第7章 ROS机器狗创意课程\4.AI视觉巡线行走(7.ROS Robot Creative Lesson\4.AI Visual Line Follow Walking) #3
import sys #4
import cv2 #5
import math #6
import time #7
import rospy #8
import threading #9
import numpy as np #10
from threading import RLock, Timer #11
from ros_robot_controller.msg import RGBState, RGBsState #12
from std_srvs.srv import * #13
from sensor_msgs.msg import Image #14
from object_tracking.srv import * #15
from puppy_control.msg import Velocity, Pose, Gait #16

from common import Misc #18


ROS_NODE_NAME = 'visual_patrol_demo' #21

is_shutdown = False #23

PuppyMove = {'x':0, 'y':0, 'yaw_rate':0} #25


color_range_list = {} #28

__isRunning = False #30
__target_color = '' #31
org_image_sub_ed = False #32


line_centerx = -1 # 线条中心坐标(line center coordinates) #35
img_centerx = 320 #36

roi = [ # [ROI, weight] #38
        (240, 280,  0, 640, 0.1),  #39
        (320, 360,  0, 640, 0.2),  #40
        (400, 440,  0, 640, 0.7) #41
       ] #42
roi = [ # [ROI, weight] #43
        (120, 140,  0, 320, 0.1),  #44
        (160, 180,  0, 320, 0.2),  #45
        (200, 220,  0, 320, 0.7) #46
       ] #47

roi_h1 = roi[0][0] #49
roi_h2 = roi[1][0] - roi[0][0] #50
roi_h3 = roi[2][0] - roi[1][0] #51
roi_h_list = [roi_h1, roi_h2, roi_h3] #52

range_rgb = { #54
    'red': (0, 0, 255), #55
    'blue': (255, 0, 0), #56
    'green': (0, 255, 0), #57
    'black': (0, 0, 0), #58
    'white': (255, 255, 255), #59
} #60
draw_color = range_rgb["black"] #61


lock = RLock() #64


# 变量重置(variable reset) #67
def reset(): #68
    global draw_color #69
    global __target_color #70
    global color_range_list #71
    global line_centerx #72
    with lock: #73
        turn_off_rgb() #74
        __target_color = 'None' #75
        line_centerx = -1 #76
        draw_color = range_rgb["black"] #77
        color_range_list = rospy.get_param('/lab_config_manager/color_range_list') #78

        PuppyMove['x'] = 0 #80
        PuppyMove['yaw_rate'] = math.radians(0) #81
        PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #82


# 初始位置(initial position) #85
def initMove(delay=True): #86
    global GaitConfig #87
    PuppyMove['x'] = 0 #88
    PuppyMove['yaw_rate'] = math.radians(0) #89
    PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #90
    rospy.sleep(0.2) #91
    rospy.ServiceProxy('/puppy_control/go_home', Empty)() #92
    PuppyPosePub.publish(stance_x=PuppyPose['stance_x'], stance_y=PuppyPose['stance_y'], x_shift=PuppyPose['x_shift'] #93
            ,height=PuppyPose['height'], roll=PuppyPose['roll'], pitch=PuppyPose['pitch'], yaw=PuppyPose['yaw'], run_time = 500) #94
    
    rospy.sleep(0.2) #96
    PuppyGaitConfigPub.publish(overlap_time = GaitConfig['overlap_time'], swing_time = GaitConfig['swing_time'] #97
                    , clearance_time = GaitConfig['clearance_time'], z_clearance = GaitConfig['z_clearance']) #98
                    
    with lock: #100
        pass #101
    if delay: #102
        rospy.sleep(0.5) #103

# 关闭RGB彩灯(close RGB color light) #105
def turn_off_rgb(): #106
    led1 = RGBState() #107
    led1.r = 0 #108
    led1.g = 0 #109
    led1.b = 0 #110
    led1.id = 1 #111

    led2 = RGBState() #113
    led2.r = 0 #114
    led2.g = 0 #115
    led2.b = 0 #116
    led2.id = 2 #117
    msg = RGBsState() #118
    msg.data = [led1,led2] #119
    rgb_pub.publish(msg) #120
    rospy.sleep(0.01) #121

def turn_on_rgb(color): #123
    led1 = RGBState() #124
    led1.r = range_rgb[color][2] #125
    led1.g = range_rgb[color][1] #126
    led1.b = range_rgb[color][0] #127
    led1.id = 1 #128

    led2 = RGBState() #130
    led2.r = range_rgb[color][2] #131
    led2.g = range_rgb[color][1] #132
    led2.b = range_rgb[color][0] #133
    led2.id = 2 #134
    msg = RGBsState() #135
    msg.data = [led1,led2] #136
    rgb_pub.publish(msg) #137
    rospy.sleep(0.01) #138

# app初始化调用(app initialization calling) #140
def init(): #141
    print("visual patrol Init") #142
    initMove(True) #143
    reset() #144

def move(): #146
    global PuppyMove #147
    global draw_color #148

    global line_centerx #150
    rospy.sleep(1) #151
    while True: #152
        if __isRunning: #153
            if line_centerx != -1: #154
                if abs(line_centerx - img_centerx) <= 50: #155
                    PuppyMove['x'] = 10 #156
                    PuppyMove['yaw_rate'] = math.radians(0) #157
                elif line_centerx - img_centerx > 50: #158
                    PuppyMove['x'] = 8 #159
                    PuppyMove['yaw_rate'] = math.radians(-15) #160
                elif line_centerx - img_centerx < -50: #161
                    PuppyMove['x'] = 8 #162
                    PuppyMove['yaw_rate'] = math.radians(15) #163
                
                PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #165
            else: #166
                PuppyMove['x'] = 0 #167
                PuppyMove['yaw_rate'] = math.radians(0) #168
                PuppyVelocityPub.publish(x=PuppyMove['x'], y=PuppyMove['y'], yaw_rate=PuppyMove['yaw_rate']) #169
            time.sleep(0.001) #170
        else: #171
            time.sleep(0.001) #172
        if is_shutdown:break #173
            
# 运行子线程(run sub-thread) #175
th = threading.Thread(target=move,daemon=True) #176
# th.start() #177

# 找出面积最大的轮廓(find out the contour with the maximal area) #179
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #180
def getAreaMaxContour(contours): #181
    contour_area_temp = 0 #182
    contour_area_max = 0 #183
    area_max_contour = None #184

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #186
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate the contour area) #187
        if contour_area_temp > contour_area_max: #188
            contour_area_max = contour_area_temp #189
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 50 are considered valid, filtering out interference) #190
                area_max_contour = c #191

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the maximal contour) #193
def run(img): #194
    global draw_color, line_centerx #195
    size = (320, 240) #196
   
    img_h, img_w = img.shape[:2] #198

    if not __isRunning: #200
        return img #201

    frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #203
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)       #204
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #205


    centroid_x_sum = 0 #208
    weight_sum = 0 #209
    center_ = [] #210
    n = 0 #211
    #将图像分割成上中下三个部分，这样处理速度会更快，更精确(divide the image to upper, middle and lower parts, which will result in faster and more accurate processing) #212
    for r in roi: #213
        roi_h = roi_h_list[n] #214
        n += 1        #215
        if n <= 2: #216
            continue #217
        blobs = frame_gb[r[0]:r[1], r[2]:r[3]] #218
        frame_lab = cv2.cvtColor(blobs, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #219
        

        for i in color_range_list: #222
            if i in __target_color: #223
                detect_color = i #224
                
                frame_mask = cv2.inRange(frame_lab, #226
                                             (color_range_list[detect_color]['min'][0], #227
                                              color_range_list[detect_color]['min'][1], #228
                                              color_range_list[detect_color]['min'][2]), #229
                                             (color_range_list[detect_color]['max'][0], #230
                                              color_range_list[detect_color]['max'][1], #231
                                              color_range_list[detect_color]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #232
                opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((6, 6), np.uint8))  # 开运算(opening operation) #233
                closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((6, 6), np.uint8))  # 闭运算(closing operation) #234
              
        if __target_color == '' or __target_color == 'None' or __target_color == None: #236
            line_centerx = -1 #237
            return img #238
        cnts = cv2.findContours(closed , cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2]#找出所有轮廓(find out all the contours) #239
        cnt_large, area = getAreaMaxContour(cnts)#找到最大面积的轮廓(find the contour with the maximal area) #240
        if cnt_large is not None:#如果轮廓不为空(if the contour is not none) #241
            rect = cv2.minAreaRect(cnt_large)#最小外接矩形(the minimal bounding rectangle) #242
            box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #243
            for i in range(4): #244
                box[i, 1] = box[i, 1] + (n - 1)*roi_h + roi[0][0] #245
                box[i, 1] = int(Misc.map(box[i, 1], 0, size[1], 0, img_h)) #246
            for i in range(4):                 #247
                box[i, 0] = int(Misc.map(box[i, 0], 0, size[0], 0, img_w)) #248
                
            cv2.drawContours(img, [box], -1, (0,0,255,255), 2)#画出四个点组成的矩形(draw a rectangle formed by connecting the four points) #250
            
            #获取矩形的对角点(get the diagonal points of the rectangle) #252
            pt1_x, pt1_y = box[0, 0], box[0, 1] #253
            pt3_x, pt3_y = box[2, 0], box[2, 1]             #254
            center_x, center_y = (pt1_x + pt3_x) / 2, (pt1_y + pt3_y) / 2#中心点(center point) #255
            cv2.circle(img, (int(center_x), int(center_y)), 5, (0,0,255), -1)#画出中心点(draw the center point) #256
            
            center_.append([center_x, center_y])                         #258
            #按权重不同对上中下三个中心点进行求和(summing up the three central points of the top, middle, and bottom with different weights) #259
            centroid_x_sum += center_x * r[4] #260
            weight_sum += r[4] #261

    if weight_sum is not 0: #263
        #求最终得到的中心点(calculate the final resulting center point) #264
        cv2.circle(img, (line_centerx, int(center_y)), 10, (0,255,255), -1)#画出中心点(draw the center point) #265
        line_centerx = int(centroid_x_sum / weight_sum)   #266
        print('line_centerx',line_centerx) #267
    else: #268
        line_centerx = -1 #269

    return img #271

def image_callback(ros_image): #273
    global lock #274
    
    image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, #276
                       buffer=ros_image.data)  # 将自定义图像消息转化为图像(convert the customize image information to image) #277
    frame = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) #278
    
    frame_result = frame #280
    with lock: #281
        if __isRunning: #282
            frame_result = run(frame) #283
            cv2.imshow('Frame', frame_result) #284
            key = cv2.waitKey(1) #285
    

def enter_func(msg): #288
    global lock #289
    global image_sub #290
    global __isRunning #291
    global org_image_sub_ed #292

    rospy.loginfo("enter visual patrol") #294
    with lock: #295
        init() #296
        if not org_image_sub_ed: #297
            org_image_sub_ed = True #298
            image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, image_callback) #299
            
    return [True, 'enter'] #301

heartbeat_timer = None #303
def exit_func(msg): #304
    global lock #305
    global image_sub #306
    global __isRunning #307
    global org_image_sub_ed #308
    
    rospy.loginfo("exit visual patrol") #310
    with lock: #311
        __isRunning = False #312
        
        reset() #314
        try: #315
            if org_image_sub_ed: #316
                org_image_sub_ed = False #317
                if heartbeat_timer:heartbeat_timer.cancel() #318
                image_sub.unregister() #319
        except: #320
            pass #321
    
    return [True, 'exit'] #323

def start_running(): #325
    global lock #326
    global __isRunning #327

    rospy.loginfo("start running") #329
    with lock: #330
        __isRunning = True #331

def stop_running(): #333
    global lock #334
    global __isRunning #335

    rospy.loginfo("stop running") #337
    with lock: #338
        __isRunning = False #339
        reset() #340

def set_running(msg): #342
    if msg.data: #343
        start_running() #344
    else: #345
        stop_running() #346
    
    return [True, 'set_running'] #348

def set_target(msg): #350
    global lock #351
    global __target_color #352
    
    rospy.loginfo("%s", msg) #354
    with lock: #355
        __target_color = msg.data #356
        turn_on_rgb(__target_color) #357
        
    return [True, 'set_target'] #359

def heartbeat_srv_cb(msg): #361
    global heartbeat_timer #362
    
    if isinstance(heartbeat_timer, Timer): #364
        heartbeat_timer.cancel() #365
    if msg.data: #366
        heartbeat_timer = Timer(5, rospy.ServiceProxy('/%s/exit'%ROS_NODE_NAME, Trigger)) #367
        heartbeat_timer.start() #368
    rsp = SetBoolResponse() #369
    rsp.success = msg.data #370

    return rsp #372

def cleanup(): #374
    global is_shutdown #375
    is_shutdown = True #376
    PuppyVelocityPub.publish(x=0, y=0, yaw_rate=0) #377
    print('is_shutdown') #378
if __name__ == '__main__': #379
    rospy.init_node(ROS_NODE_NAME, log_level=rospy.INFO) #380
    rospy.on_shutdown(cleanup) #381
    
    PP = rospy.get_param('/puppy_control/PuppyPose') #383
    PuppyPose = PP['LookDown_20deg'].copy() #384
    
    GaitConfig = {'overlap_time':0.1, 'swing_time':0.15, 'clearance_time':0.0, 'z_clearance':3} #386
    
    image_pub = rospy.Publisher('/%s/image_result'%ROS_NODE_NAME, Image, queue_size=1)  # register result image publisher #388
    rgb_pub = rospy.Publisher('/ros_robot_controller/set_rgb', RGBsState, queue_size=1) #389

    PuppyGaitConfigPub = rospy.Publisher('/puppy_control/gait', Gait, queue_size=1) #391
    PuppyVelocityPub = rospy.Publisher('/puppy_control/velocity', Velocity, queue_size=1) #392
    PuppyPosePub = rospy.Publisher('/puppy_control/pose', Pose, queue_size=1) #393
    rospy.sleep(0.2) #394
    
    th.start() #396
    debug = True #397
    if debug: #398
        enter_func(1) #399
        start_running() #400
        __target_color = 'red' #401
    try: #402
        rospy.spin() #403
    except KeyboardInterrupt: #404
        print("Shutting down") #405
    finally: #406
        cv2.destroyAllWindows() #407
