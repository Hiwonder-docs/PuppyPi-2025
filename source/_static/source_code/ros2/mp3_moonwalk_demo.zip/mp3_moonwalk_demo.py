#!/usr/bin/env python3
# coding=utf8
# 第7课 MP3模块实验(Lesson 7 MP3 Module)
import math
import rclpy
import time
import signal
import sdk.mp3 as mp3
from rclpy.node import Node
from puppy_control_msgs.srv import SetRunActionName
from puppy_control_msgs.msg import Velocity, Pose, Gait

print('''
**********************************************************
******************功能:MP3模块例程(function: MP3 module routine)*************************
**********************************************************
----------------------------------------------------------
Official website:https://www.hiwonder.com
Online mall:https://hiwonder.tmall.com
----------------------------------------------------------
Tips:
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！(press Ctrl+C to close the program, please try multiple times if fail)
----------------------------------------------------------
''')


class Mp3MoonwalkDemo(Node):
    def __init__(self):
        super().__init__('mp3_moonwalk_demo')
        signal.signal(signal.SIGINT, self.stop) 
               
        # 创建发布者和客户端    
        self.pose_publisher = self.create_publisher(Pose, '/puppy_control/pose',10)
        self.gait_publisher = self.create_publisher(Gait, '/puppy_control/gait', 10)
        self.velocity_publisher = self.create_publisher(Velocity, '/puppy_control/velocity',10)
        self.run_action_group_srv = self.create_client(SetRunActionName, '/puppy_control/runActionGroup',)
        
        # 初始化机器狗姿态和步态
        self.set_pose()
        self.set_gait()
                   
           
        # MP3模块初始化
        self.addr = 0x7b #传感器iic地址(sensor I2C address)
        self.mp3 = mp3.MP3(self.addr)
        self.mp3.volume(30) #设置音量为20，注意在播放前设置(set the volume to 20, note that set before playback)
        self.mp3.playNum(25) #播放歌曲3(play song number 3)       
        self.mp3.play() #播放(play)
        
        # 执行动作   
        self.timer = self.create_timer(0.1, self.mp3_moon_callback)  
           
   
    def mp3_moon_callback(self):
        # 原地踏步(stepping in place)
        self.set_move(x=0.01) 
        time.sleep(3)
        self.set_move(x=0.0)
        time.sleep(1)
        
        # 多轴联动(multi-axis linkage)
        self.linkage(2) 
        
    
        # 机器狗站立(robot dog stands up)
        self.set_pose()
        
        # 向前走(move forward)
        self.set_move(x=5.0)
        time.sleep(3)      
        # 向后走(walk backward)
        self.set_move(x=-5.0) 
        time.sleep(2)
        # 停止(stop)
        self.set_move(x=0.0) 
        time.sleep(1)
        
        # 执行滑步动作组(perform the sliding step action group)
        msg = SetRunActionName.Request()
        msg.name = 'moonwalk.d6ac'
        msg.wait = True
        self.run_action_group_srv.call_async(msg)
        time.sleep(0.1)
        self.run_action_group_srv.call_async(msg)
        time.sleep(0.1)
        
        # 机器狗站立(robot dog stands up)
        self.set_pose()
        time.sleep(0.5)
        
        # 向前走(move forward)
        self.set_move(x=5.0)
        time.sleep(3)      
        # 向后走(walk backward)
        self.set_move(x=-5.0) 
        time.sleep(2)
        # 停止(stop)
        self.set_move()
        time.sleep(1)
        
        
    def linkage(self, times = 1):        
        # times:循环次数(number of iterations)
        for i in range(0,15,1):
            self.set_pose(roll=math.radians(i),run_time = 30)
            time.sleep(0.03)
        for i in range(0,15,1):
            self.set_pose(pitch=math.radians(i),run_time = 30)
            time.sleep(0.03)
            
        for s in range(times):
            for i in range(15,-15,-1):
                self.set_pose(roll=math.radians(i),pitch=math.radians(15),run_time = 30)
                time.sleep(0.03)
            for i in range(15,-15,-1):
                self.set_pose(roll=math.radians(-15),pitch=math.radians(i),run_time = 30)
                time.sleep(0.03)
                 
            for i in range(-15,15,1):
                self.set_pose(roll=math.radians(i),pitch=math.radians(-15),run_time = 30)
                time.sleep(0.03)
            for i in range(-15,15,1):
                self.set_pose(roll=math.radians(15),pitch=math.radians(i),run_time = 30)
                time.sleep(0.03)
                
    def set_pose(self,roll=math.radians(0), pitch=math.radians(0), yaw=0.000, height=-10.0, x_shift=0.5, stance_x= 0.0, stance_y=0.0,run_time=500):
        # stance_x：4条腿在x轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the X-axis, measured in centimeters)
        # stance_y：4条腿在y轴上额外分开的距离，单位cm(the distance extra apart for each of the four legs on the Y-axis, measured in centimeters)
        # x_shift: 4条腿在x轴上同向移动的距离，越小，走路越前倾，越大越后仰,通过调节x_shift可以调节小狗走路的平衡，单位cm(the distance traveled by the four legs along the x-axis determines the degree of forward or backward tilt during walking: smaller distances lead to more forward tilt, while larger distances result in more backward tilt. Adjusting the x_shift parameter can help maintain balance during the dog's movement, measured in centimeters)
        # height： 狗的高度，脚尖到大腿转动轴的垂直距离，单位cm(the height of the dog, measured from the toe to the axis  of rotation of the thigh, is in centimeters)
        # pitch： 狗身体的俯仰角，单位弧度(the pitch angle of the dog's body, measured in radians)  
        self.pose_publisher.publish(Pose(stance_x=stance_x, stance_y=stance_y, x_shift=x_shift,
                                           height=height, roll=roll, pitch=pitch, yaw=yaw, run_time=500))
                                           
    def set_gait(self,overlap_time = 0.3, swing_time = 0.2, clearance_time = 0.0, z_clearance = 5.0):
        # overlap_time:4脚全部着地的时间，单位秒(the time when all four legs touch the ground, measured in seconds)
        # swing_time：2脚离地时间，单位秒(the time duration when legs are off the ground, measured in second)
        # clearance_time：前后脚间隔时间，单位秒(the time interval between the front and rear legs, measured in seconds)
        # z_clearance：走路时，脚抬高的距离，单位cm(the distance the paw needs to be raised during walking, measured in centimeters)

        self.gait_publisher.publish(Gait(overlap_time = overlap_time, swing_time = swing_time, clearance_time =clearance_time, z_clearance = z_clearance))
        
    def set_move(self, x=0.00, y=0.0, yaw_rate=0.0):
        self.velocity_publisher.publish(Velocity(x=x, y=y, yaw_rate=yaw_rate)) 
                    
    def stop(self):
        self.velocity_publisher.publish(Velocity(x=0.0, y=0.0, yaw_rate=0.0))
        self.mp3.pause() 
        self.get_logger().info('Shutting down...')
        
def main(args=None):
    rclpy.init(args=args)
    node = Mp3MoonwalkDemo()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("intteruprt------------")
        pass

    finally:
        node.stop()
        node.destroy_node()
        rclpy.shutdown()
 

if __name__ == '__main__':
    main()
